// Service worker không được chặn/lưu đệm API hay yêu cầu có xác thực (lỗi rò rỉ dữ liệu giữa người dùng trên máy dùng chung).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

function loadSW() {
  const handlers = {}, store = new Map(); let network = 0;
  const caches = { open: async () => ({ put: async (r, res) => store.set(r.url, res), add: async () => {}, match: async r => store.get(r.url) }), match: async r => store.get(r.url), keys: async () => [], delete: async () => {} };
  const sb = { self: { addEventListener: (t, f) => handlers[t] = f, skipWaiting() {}, clients: { claim() {} } }, caches, location: { origin: 'https://app.example.vn' }, URL, Promise,
    fetch: async req => { network++; return { clone() { return this; }, url: req.url }; } };
  vm.createContext(sb); vm.runInContext(fs.readFileSync(new URL('../../sw.js', import.meta.url), 'utf8'), sb);
  const req = (path, auth) => ({ method: 'GET', url: 'https://app.example.vn' + path, mode: 'cors', headers: { get: () => auth || null, has: k => k === 'Authorization' && !!auth } });
  const fire = async r => { let handled = false, out; handlers.fetch({ request: r, respondWith: p => { handled = true; out = p; } }); if (handled) await out; return handled; };
  return { fire, req, network: () => network };
}
test('GET /api/... không bị service worker can thiệp (kể cả có Authorization)', async () => {
  const sw = loadSW();
  assert.equal(await sw.fire(sw.req('/api/certificates/mine', 'Bearer A')), false);
  assert.equal(await sw.fire(sw.req('/api/admin/users', 'Bearer B')), false);
  assert.equal(await sw.fire(sw.req('/api/auth/me')), false);
});
test('Mọi yêu cầu có Authorization đều không được lưu đệm', async () => {
  const sw = loadSW();
  assert.equal(await sw.fire(sw.req('/du-lieu/bat-ky', 'Bearer A')), false);
});
test('Tệp giao diện thường vẫn được service worker xử lý (chạy offline)', async () => {
  const sw = loadSW();
  assert.equal(await sw.fire(sw.req('/index.html')), true);
  assert.equal(await sw.fire(sw.req('/icons/icon-192.png')), true);
});
test('Hai người dùng nối tiếp không nhận phản hồi của nhau', async () => {
  const sw = loadSW();
  await sw.fire(sw.req('/api/certificates/mine', 'Bearer A')); await sw.fire(sw.req('/api/certificates/mine', 'Bearer B'));
  assert.equal(sw.network(), 0, 'SW không được tự gọi mạng/lưu đệm cho API');
});
