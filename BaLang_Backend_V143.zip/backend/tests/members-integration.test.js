// V140 – Hồ sơ đoàn viên trên PostgreSQL: kiểm thử tích hợp THẬT (Express + PostgreSQL). Cần TEST_DATABASE_URL (CSDL có chữ "test").
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { randomBytes, randomUUID } from 'node:crypto';
import jwt from 'jsonwebtoken';
import pg from 'pg';

const DB = process.env.TEST_DATABASE_URL;
if (DB && !/test/i.test(new URL(DB).pathname)) throw new Error('TEST_DATABASE_URL phải trỏ tới CSDL có chữ "test".');
const skip = DB ? false : 'Thiếu TEST_DATABASE_URL.';
const PORT = 5100 + Math.floor(Math.random() * 300), BASE = `http://127.0.0.1:${PORT}`;
const SECRET = 'kiem-thu-members-' + randomBytes(32).toString('hex');
const ORG = 'V140-MEM', ORG2 = 'V140-KHAC', RUN = randomBytes(3).toString('hex');
let server, pool; const ids = {};
const env = { ...process.env, NODE_ENV: 'test', PORT: String(PORT), DATABASE_URL: DB, JWT_SECRET: SECRET, PUBLIC_APP_URL: 'http://localhost/index.html', CORS_ORIGINS: '' };
const call = async (method, path, { token, body } = {}) => {
  const r = await fetch(BASE + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
  let j = null; try { j = await r.json(); } catch {} return { status: r.status, body: j };
};
async function sessionFor(userId, role, org = ORG) {
  const sid = randomUUID(); const token = jwt.sign({ org, role, sid }, SECRET, { subject: userId, algorithm: 'HS256', expiresIn: '1h' });
  await pool.query('INSERT INTO auth_sessions(id,user_id,organization_id,expires_at) VALUES($1,$2,$3,to_timestamp($4))', [sid, userId, org, jwt.decode(token).exp]);
  return { token, sid };
}
const nm = (base) => `${base} ${RUN}`;
const mkUser = async (org, username, role, member = null) => (await pool.query(
  `INSERT INTO users(organization_id,member_id,username,username_key,password_hash,role,status) VALUES($1,$2,$3,$4,'x',$5,'ACTIVE') RETURNING id`, [org, member, username, username.toLowerCase(), role])).rows[0].id;

before(async () => {
  if (skip) return;
  pool = new pg.Pool({ connectionString: DB });
  await pool.query(`INSERT INTO organizations(id,name) VALUES($1,'Đơn vị thử hồ sơ'),($2,'Đơn vị khác') ON CONFLICT DO NOTHING`, [ORG, ORG2]);
  ids.admin = await mkUser(ORG, 'bithu.' + RUN, 'Bí thư');
  ids.member = await mkUser(ORG, 'dv.' + RUN, 'Đoàn viên');
  ids.admin2 = await mkUser(ORG2, 'bithu2.' + RUN, 'Bí thư');
  server = spawn('node', ['src/server.js'], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  await new Promise((ok, bad) => { const t = setTimeout(() => bad(new Error('Máy chủ không khởi động')), 15000);
    server.stdout.on('data', d => { if (String(d).includes('listening')) { clearTimeout(t); ok(); } }); server.on('exit', c => bad(new Error('Máy chủ thoát sớm ' + c))); });
  ids.a = (await sessionFor(ids.admin, 'Bí thư')).token;
  ids.m = (await sessionFor(ids.member, 'Đoàn viên')).token;
  ids.a2 = (await sessionFor(ids.admin2, 'Bí thư', ORG2)).token;
});
after(async () => { if (server) server.kill(); if (pool) await pool.end(); });

const full = (over = {}) => ({ fullName: nm('Nguyễn Văn Thử'), birthDate: '2001-05-20', gender: 'Nam', phone: '0905' + String(Math.floor(Math.random() * 1e6)).padStart(6, '0'), kind: 'Đoàn viên', ...over });

test('Khách: mọi route hồ sơ đoàn viên đều 401', { skip }, async () => {
  for (const [m, p] of [['GET', '/api/members'], ['GET', '/api/members/me'], ['GET', '/api/members/x'], ['GET', '/api/members/x/history'], ['POST', '/api/members'], ['PATCH', '/api/members/x'], ['POST', '/api/members/x/status'], ['POST', '/api/members/x/archive'], ['POST', '/api/members/import']])
    assert.equal((await call(m, p, { body: m === 'GET' ? undefined : {} })).status, 401, `${m} ${p}`);
});
test('Đoàn viên không có quyền: 403 ở mọi chức năng quản lý hồ sơ', { skip }, async () => {
  for (const [m, p, b] of [['GET', '/api/members'], ['GET', '/api/members/x'], ['GET', '/api/members/x/history'], ['POST', '/api/members', full()], ['PATCH', '/api/members/x', { expectedVersion: 1 }],
    ['POST', '/api/members/x/status', {}], ['POST', '/api/members/x/archive', {}], ['POST', '/api/members/import', { members: [{ id: 'a', name: 'Ab' }] }]])
    assert.equal((await call(m, p, { token: ids.m, body: b })).status, 403, `${m} ${p}`);
  assert.equal((await call('GET', '/api/members/me', { token: ids.m })).status, 404, 'chưa gắn hồ sơ -> 404, không lộ hồ sơ khác');
});
test('Bí thư tạo hồ sơ: mã duy nhất, phiên bản 1, có lịch sử "Tạo hồ sơ"', { skip }, async () => {
  const r = await call('POST', '/api/members', { token: ids.a, body: full({ fullName: nm('Trần Thị Mới') }) });
  assert.equal(r.status, 201, JSON.stringify(r.body)); ids.m1 = r.body.member;
  assert.match(r.body.member.id, /^DV\d{4}-V140-MEM$/); assert.equal(r.body.member.version, 1); assert.equal(r.body.member.activityStatus, 'Đang sinh hoạt');
  const r2 = await call('POST', '/api/members', { token: ids.a, body: full({ fullName: nm('Lê Văn Hai') }) });
  assert.notEqual(r2.body.member.id, r.body.member.id); ids.m2 = r2.body.member;
  const h = await call('GET', `/api/members/${ids.m1.id}/history`, { token: ids.a });
  assert.equal(h.body.history[0].type, 'Tạo hồ sơ');
  assert.equal((await pool.query('SELECT member_status FROM members WHERE id=$1', [ids.m1.id])).rows[0].member_status, 'ACTIVE');
});
test('Dữ liệu sai bị từ chối 400 (SĐT, ngày, trường lạ, họ tên ngắn)', { skip }, async () => {
  for (const bad of [full({ phone: 'abc' }), full({ birthDate: '2001-13-45' }), full({ fullName: 'A' }), { ...full(), isAdmin: true }, full({ gender: 'X' }), full({ email: 'khong-phai-email' })])
    assert.equal((await call('POST', '/api/members', { token: ids.a, body: bad })).status, 400, JSON.stringify(bad));
});
test('Phát hiện trùng: cùng họ tên+ngày sinh hoặc cùng SĐT -> 409; xác nhận mới tạo được', { skip }, async () => {
  const dup = await call('POST', '/api/members', { token: ids.a, body: full({ fullName: nm('trần thị mới'), birthDate: '2001-05-20' }) });
  const base = await call('GET', `/api/members/${ids.m1.id}`, { token: ids.a });
  const sameName = await call('POST', '/api/members', { token: ids.a, body: { fullName: ids.m1.fullName, birthDate: ids.m1.birthDate, phone: '0999000111' } });
  assert.equal(sameName.status, 409); assert.equal(sameName.body.code, 'DUPLICATE_CANDIDATE'); assert.equal(sameName.body.candidates[0].id, ids.m1.id);
  const samePhone = await call('POST', '/api/members', { token: ids.a, body: full({ fullName: nm('Người Khác Hẳn'), phone: base.body.member.phone }) });
  assert.equal(samePhone.status, 409);
  const ok = await call('POST', '/api/members', { token: ids.a, body: { ...full({ fullName: nm('Trần Thị Mới'), birthDate: ids.m1.birthDate }), confirmNotDuplicate: true } });
  assert.equal(ok.status, 201); void dup;
});
test('Hai người sửa cùng lúc: đúng một người thành công, người kia nhận 409 VERSION_CONFLICT', { skip }, async () => {
  const id = ids.m2.id;
  const [x, y] = await Promise.all([
    call('PATCH', `/api/members/${id}`, { token: ids.a, body: { expectedVersion: 1, address: 'Thôn Ba Lăng – A' } }),
    call('PATCH', `/api/members/${id}`, { token: ids.a, body: { expectedVersion: 1, address: 'Thôn Ba Lăng – B' } })]);
  assert.deepEqual([x.status, y.status].sort(), [200, 409]);
  const loser = x.status === 409 ? x : y; assert.equal(loser.body.code, 'VERSION_CONFLICT'); assert.equal(loser.body.currentVersion, 2);
  assert.equal((await pool.query('SELECT version FROM members WHERE id=$1', [id])).rows[0].version, 2, 'không bị ghi đè hai lần');
});
test('Sửa hồ sơ ghi lịch sử thay đổi (giá trị cũ/mới); không đổi gì thì không tăng phiên bản', { skip }, async () => {
  const cur = (await call('GET', `/api/members/${ids.m1.id}`, { token: ids.a })).body.member;
  const r = await call('PATCH', `/api/members/${cur.id}`, { token: ids.a, body: { expectedVersion: cur.version, occupation: 'Giáo viên', groupName: 'Đội 2' } });
  assert.equal(r.status, 200); assert.equal(r.body.member.version, cur.version + 1);
  const same = await call('PATCH', `/api/members/${cur.id}`, { token: ids.a, body: { expectedVersion: r.body.member.version, occupation: 'Giáo viên' } });
  assert.equal(same.body.unchanged, true); assert.equal(same.body.member.version, r.body.member.version);
  const h = (await call('GET', `/api/members/${cur.id}/history`, { token: ids.a })).body.history[0];
  assert.equal(h.type, 'Cập nhật hồ sơ'); assert.equal(h.details.changes.occupation.to, 'Giáo viên'); assert.equal(h.details.changes.occupation.from, null);
  assert.equal((await call('PATCH', `/api/members/${cur.id}`, { token: ids.a, body: { occupation: 'x' } })).status, 400, 'thiếu expectedVersion');
});
test('Chuyển đi: đổi trạng thái, ghi lịch sử, không xóa; QR chỉ nhận người đang sinh hoạt', { skip }, async () => {
  const cur = (await call('GET', `/api/members/${ids.m2.id}`, { token: ids.a })).body.member;
  const r = await call('POST', `/api/members/${cur.id}/status`, { token: ids.a, body: { status: 'Chuyển sinh hoạt', effectiveDate: '2026-10-01', destination: 'Chi đoàn thôn Khác', note: 'Đi làm xa', expectedVersion: cur.version } });
  assert.equal(r.status, 200); assert.equal(r.body.member.activityStatus, 'Chuyển sinh hoạt');
  assert.equal((await pool.query('SELECT member_status FROM members WHERE id=$1', [cur.id])).rows[0].member_status, 'INACTIVE');
  const h = (await call('GET', `/api/members/${cur.id}/history`, { token: ids.a })).body.history;
  assert.equal(h[0].type, 'Chuyển sinh hoạt'); assert.equal(h[0].date, '2026-10-01'); assert.equal(h[0].details.destination, 'Chi đoàn thôn Khác'); assert.ok(h.some(x => x.type === 'Tạo hồ sơ'), 'lịch sử cũ vẫn còn');
  assert.equal((await call('POST', `/api/members/${cur.id}/status`, { token: ids.a, body: { status: 'Đang sinh hoạt', effectiveDate: '2026-10-02', expectedVersion: cur.version } })).status, 409, 'dùng phiên bản cũ bị chặn');
});
test('Lưu trữ thay cho xóa: cần lý do, khóa tài khoản + thu hồi phiên, ẩn khỏi danh sách mặc định', { skip }, async () => {
  const mem = (await call('POST', '/api/members', { token: ids.a, body: full({ fullName: nm('Phạm Văn Rời') }) })).body.member;
  const uid = await mkUser(ORG, 'roi.' + RUN, 'Đoàn viên', mem.id); const s = await sessionFor(uid, 'Đoàn viên');
  assert.equal((await call('GET', '/api/members/me', { token: s.token })).status, 200, 'đoàn viên xem được hồ sơ của chính mình');
  assert.equal((await call('POST', `/api/members/${mem.id}/archive`, { token: ids.a, body: { reason: '', expectedVersion: 1 } })).status, 400);
  assert.equal((await call('POST', `/api/members/${mem.id}/archive`, { token: ids.a, body: { reason: 'Đã rời địa bàn', expectedVersion: 1 } })).status, 200);
  assert.equal((await call('GET', '/api/members/me', { token: s.token })).status, 401, 'phiên bị thu hồi ngay');
  assert.equal((await pool.query('SELECT status FROM users WHERE id=$1', [uid])).rows[0].status, 'LOCKED');
  const def = (await call('GET', `/api/members?q=${encodeURIComponent('Phạm Văn Rời')}`, { token: ids.a })).body.members;
  assert.ok(!def.some(x => x.id === mem.id)); assert.ok((await call('GET', '/api/members?archived=true', { token: ids.a })).body.members.some(x => x.id === mem.id));
  const cur = (await call('GET', `/api/members/${mem.id}`, { token: ids.a })).body.member;
  assert.equal((await call('PATCH', `/api/members/${mem.id}`, { token: ids.a, body: { expectedVersion: cur.version, notes: 'x' } })).body.code, 'ARCHIVED');
  assert.ok((await call('GET', `/api/members/${mem.id}/history`, { token: ids.a })).body.history.some(h => h.type === 'Lưu trữ hồ sơ'), 'lịch sử còn nguyên');
});
test('Cơ sở dữ liệu tự chặn xóa hồ sơ và sửa/xóa lịch sử (kể cả khi chạy SQL trực tiếp)', { skip }, async () => {
  await assert.rejects(pool.query('DELETE FROM members WHERE id=$1', [ids.m1.id]), /Không xóa hồ sơ/);
  await assert.rejects(pool.query('UPDATE member_history SET description=$1 WHERE member_id=$2', ['sửa lén', ids.m1.id]), /chỉ được thêm/);
  await assert.rejects(pool.query('DELETE FROM member_history WHERE member_id=$1', [ids.m1.id]), /chỉ được thêm/);
});
test('Không đoán ID để xem/sửa hồ sơ đơn vị khác; danh sách tách biệt theo đơn vị', { skip }, async () => {
  assert.equal((await call('GET', `/api/members/${ids.m1.id}`, { token: ids.a2 })).status, 404);
  assert.equal((await call('GET', `/api/members/${ids.m1.id}/history`, { token: ids.a2 })).status, 404);
  assert.equal((await call('PATCH', `/api/members/${ids.m1.id}`, { token: ids.a2, body: { expectedVersion: 1, notes: 'hack' } })).status, 404);
  assert.equal((await call('POST', `/api/members/${ids.m1.id}/archive`, { token: ids.a2, body: { reason: 'thử xem', expectedVersion: 1 } })).status, 404);
  assert.ok(!(await call('GET', '/api/members', { token: ids.a2 })).body.members.some(x => x.id === ids.m1.id));
});
test('Tìm kiếm an toàn: chuỗi tấn công SQL và ký tự đại diện không làm lộ thêm dữ liệu', { skip }, async () => {
  const total = (await call('GET', '/api/members', { token: ids.a })).body.total;
  for (const q of ["' OR 1=1 --", "%", "_", "\\"]) { const r = await call('GET', `/api/members?q=${encodeURIComponent(q)}`, { token: ids.a }); assert.equal(r.status, 200); assert.ok(r.body.total < total, `q=${q} không được khớp tất cả`); }
  const found = await call('GET', `/api/members?q=${encodeURIComponent(RUN)}&limit=2`, { token: ids.a }); assert.ok(found.body.members.length <= 2);
});
test('Nhập hàng loạt từ bản sao lưu cũ: chỉ Bí thư, an toàn khi chạy lại, cảnh báo dữ liệu xấu', { skip }, async () => {
  const p = 'LG' + RUN;
  const payload = { members: [
    { id: p + '1', name: nm('Hoàng Văn Cũ'), birth: '1999-01-02', gender: 'Nam', phone: '0912345678', status: 'Đang sinh hoạt', joined: 'Đã kết nạp Đoàn', group: 'Đội 1' },
    { id: p + '2', name: nm('Đinh Thị Lỗi'), birth: 'không-phải-ngày', phone: '12', status: 'Tình trạng lạ' },
    { id: p + '3', name: nm('Hoàng Văn Cũ'), birth: '1999-01-02' }],
  memberHistory: [{ memberId: p + '1', type: 'Kết nạp', date: '2020-03-26', description: 'Kết nạp Đoàn' }, { memberId: 'khong-co', type: 'X' }] };
  assert.equal((await call('POST', '/api/members/import', { token: ids.m, body: payload })).status, 403);
  const r = await call('POST', '/api/members/import', { token: ids.a, body: payload });
  assert.equal(r.status, 201, JSON.stringify(r.body)); assert.equal(r.body.report.created, 3); assert.equal(r.body.report.historyAdded, 1);
  assert.ok(r.body.report.warnings.some(w => w.id === p + '2' && w.field === 'birth')); assert.ok(r.body.report.warnings.some(w => w.id === p + '2' && w.field === 'phone'));
  assert.ok(r.body.report.warnings.some(w => w.id === p + '3' && w.field === 'name'), 'phát hiện nghi trùng');
  const again = await call('POST', '/api/members/import', { token: ids.a, body: payload });
  assert.equal(again.body.report.created, 0); assert.equal(again.body.report.skippedExisting, 3); assert.equal(again.body.report.historyAdded, 0, 'nhập lại không nhân đôi lịch sử');
  const m2 = (await call('GET', `/api/members/${p}2`, { token: ids.a })).body.member; assert.equal(m2.birthDate, null); assert.equal(m2.activityStatus, 'Đang sinh hoạt');
  const other = await call('POST', '/api/members/import', { token: ids.a2, body: { members: [{ id: p + '1', name: nm('Kẻ Chiếm Mã') }] } });
  assert.equal(other.body.report.created, 0); assert.equal(other.body.report.rejected.length, 1, 'không chiếm mã của đơn vị khác');
  assert.equal((await call('POST', '/api/members/import', { token: ids.a, body: { members: [] } })).status, 400);
  const big = { members: Array.from({ length: 501 }, (_, i) => ({ id: 'B' + i, name: 'Nguyễn Văn B' })) }; assert.equal((await call('POST', '/api/members/import', { token: ids.a, body: big })).status, 400);
});

test('Trạng thái sinh hoạt đúng bộ giá trị của Chi đoàn; thêm "Họ tên bố/mẹ"; nhập Excel không có cột mã thì hệ thống cấp mã', { skip }, async () => {
  const m = (await call('POST', '/api/members', { token: ids.a, body: full({ fullName: nm('Võ Thị Bố Mẹ'), parents: 'Võ Văn Cha - Lê Thị Mẹ', activityStatus: 'Học tập/làm việc xa' }) })).body.member;
  assert.equal(m.parents, 'Võ Văn Cha - Lê Thị Mẹ'); assert.equal(m.activityStatus, 'Học tập/làm việc xa');
  assert.equal((await pool.query('SELECT member_status FROM members WHERE id=$1', [m.id])).rows[0].member_status, 'INACTIVE', 'chỉ "Đang sinh hoạt" mới điểm danh được');
  for (const bad of ['Tạm ngừng sinh hoạt', 'Đã chuyển đi', 'Lung tung']) assert.equal((await call('POST', '/api/members', { token: ids.a, body: full({ activityStatus: bad }) })).status, 400, bad);
  for (const ok of ['Trưởng thành Đoàn', 'Chờ bổ sung', 'Không còn sinh hoạt']) assert.equal((await call('POST', `/api/members/${m.id}/status`, { token: ids.a, body: { status: ok, effectiveDate: '2026-11-01', expectedVersion: (await call('GET', `/api/members/${m.id}`, { token: ids.a })).body.member.version } })).status, 200, ok);
  const r = await call('POST', '/api/members/import', { token: ids.a, body: { members: [{ name: nm('Không Có Mã Một'), phone: '0933111222', parents: 'Cha Mẹ' }, { name: nm('Không Có Mã Hai') }] } });
  assert.equal(r.status, 201, JSON.stringify(r.body)); assert.equal(r.body.report.created, 2);
  const list = (await call('GET', `/api/members?q=${encodeURIComponent(RUN)}&limit=200`, { token: ids.a })).body.members.filter(x => x.fullName.includes('Không Có Mã'));   // dữ liệu các lần chạy trước còn lại trong CSDL thử
  assert.equal(list.length, 2); assert.ok(list.every(x => /^DV\d{4}-V140-MEM$/.test(x.id))); assert.equal(list.find(x => x.phone === '0933111222').parents, 'Cha Mẹ');
});
