import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const sql=fs.readFileSync(path.join(root,'migrations/001_qr_attendance.sql'),'utf8');
const routes=fs.readFileSync(path.join(root,'src/routes/qr.js'),'utf8');

test('database enforces one attendance record per member/activity/organization',()=>{
  assert.match(sql,/UNIQUE\s*\(organization_id,\s*activity_id,\s*member_id\)/i);
});
test('QR tokens are stored as hashes and have expiry and revocation states',()=>{
  assert.match(sql,/token_hash\s+text/i); assert.match(sql,/token_expires_at\s+timestamptz/i);
  for(const state of ['OPEN','PAUSED','CLOSED','REVOKED']) assert.ok(sql.includes(`'${state}'`));
});
test('check-in identity comes from authenticated user, not submitted memberId',()=>{
  const block=routes.slice(routes.indexOf("router.post('/check-in'"),routes.indexOf("router.get('/my-attendance'"));
  assert.match(block,/req\.user\.member_id/); assert.doesNotMatch(block,/req\.body\.memberId/);
});
test('session creation and token rotation are restricted to Secretary',()=>{
  assert.match(routes,/const managers = allowRoles\('Bí thư'\)/);
  assert.match(routes,/router\.post\('\/sessions',managers/);
  assert.match(routes,/router\.post\('\/sessions\/:id\/rotate',managers/);
});
