import test from 'node:test';
import assert from 'node:assert/strict';
import { makeOpaqueToken, hashToken, lateMinutes } from '../src/security.js';

test('QR token is random, opaque and hash is one-way stable',()=>{
  const a=makeOpaqueToken(),b=makeOpaqueToken();
  assert.notEqual(a,b); assert.ok(a.length>=40); assert.equal(hashToken(a),hashToken(a)); assert.notEqual(hashToken(a),a);
});
test('late minutes are calculated against Vietnam local activity time',()=>{
  const now=new Date('2026-11-05T02:15:00.000Z'); // 09:15 UTC+7
  assert.equal(lateMinutes('2026-11-05','09:00:00',now),15);
  assert.equal(lateMinutes('2026-11-05','09:30:00',now),0);
});
