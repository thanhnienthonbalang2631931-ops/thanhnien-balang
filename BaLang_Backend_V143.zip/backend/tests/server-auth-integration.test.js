// V138 – Kiểm thử tích hợp THẬT: máy chủ Express + PostgreSQL.
// Chạy:  TEST_DATABASE_URL=postgres://... npm test   (đã chạy migration 001–004 trên CSDL thử)
// Không có TEST_DATABASE_URL thì các kiểm thử này bị bỏ qua (không giả lập kết quả).
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pg from 'pg';

const DB = process.env.TEST_DATABASE_URL;
if (DB && !/test/i.test(new URL(DB).pathname)) throw new Error('TEST_DATABASE_URL phải trỏ tới CSDL có chữ "test" trong tên – kiểm thử xoá dữ liệu.');
const skip = DB ? false : 'Thiếu TEST_DATABASE_URL – không chạy kiểm thử tích hợp.';
const PORT = 4600 + Math.floor(Math.random() * 300);
const BASE = `http://127.0.0.1:${PORT}`;
const SECRET = 'kiem-thu-v138-' + randomBytes(32).toString('hex');
const ADMIN_USERNAME = 'TKBTCĐTBL';
const ADMIN_PASSWORD = 'Mat-khau-thu-' + randomBytes(9).toString('hex');
const ORG = 'V138-TEST';
let server, pool;
const ids = {};
const RUN = randomBytes(3).toString('hex');   // tên đăng nhập là duy nhất toàn hệ thống: dùng hậu tố riêng mỗi lần chạy
const NEWUSER = 'Nguyen.Van.An' + RUN, NEWMEM = 'dv-an-' + RUN;

const env = { ...process.env, NODE_ENV: 'test', PORT: String(PORT), DATABASE_URL: DB, JWT_SECRET: SECRET, PUBLIC_APP_URL: 'http://localhost/index.html', CORS_ORIGINS: '', TRUST_PROXY: '1' };
const call = async (method, path, { token, body } = {}) => {
  const r = await fetch(BASE + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
  let j = null; try { j = await r.json(); } catch {}
  return { status: r.status, body: j };
};
// Phiên đăng nhập hợp lệ tạo thẳng trong CSDL để các kiểm thử phân quyền không làm cạn giới hạn 8 lần đăng nhập / 15 phút.
async function sessionFor(userId, role, secret = SECRET) {
  const sid = (await pool.query('SELECT gen_random_uuid() AS id')).rows[0].id;
  const token = jwt.sign({ org: ORG, role, sid }, secret, { subject: userId, algorithm: 'HS256', expiresIn: '1h' });
  const exp = jwt.decode(token).exp;
  await pool.query('INSERT INTO auth_sessions(id,user_id,organization_id,expires_at) VALUES($1,$2,$3,to_timestamp($4))', [sid, userId, ORG, exp]);
  return { token, sid };
}

before(async () => {
  if (skip) return;
  pool = new pg.Pool({ connectionString: DB });
  // Chỉ dọn tài khoản của chính bài test này (và tài khoản quản trị cùng tên còn sót từ lần chạy thử khác).
  // Không dọn toàn bảng: tài khoản đã tạo lịch sử hồ sơ không được phép xóa (đúng thiết kế).
  const victims = (await pool.query('SELECT id FROM users WHERE organization_id=$1 OR username_key=$2', [ORG, 'tkbtcđtbl'])).rows.map(r => r.id);
  await pool.query('DELETE FROM auth_sessions WHERE user_id=ANY($1::uuid[])', [victims]);
  await pool.query('DELETE FROM audit_logs WHERE actor_user_id=ANY($1::uuid[]) OR organization_id=$2', [victims, ORG]);
  await pool.query('UPDATE users SET created_by=NULL WHERE created_by=ANY($1::uuid[])', [victims]);
  await pool.query('UPDATE members SET updated_by=NULL WHERE updated_by=ANY($1::uuid[])', [victims]);
  await pool.query('DELETE FROM users WHERE id=ANY($1::uuid[])', [victims]);
  await pool.query(`INSERT INTO organizations(id,name) VALUES($1,'Đơn vị thử V138') ON CONFLICT DO NOTHING`, [ORG]);
  await pool.query(`INSERT INTO members(id,organization_id,full_name) VALUES('tv1',$1,'Đoàn viên Thử'),('pb1',$1,'Phó Bí thư Thử'),('lk1',$1,'Đoàn viên Khóa'),('lo1',$1,'Đoàn viên Thử Khóa Tạm'),('lo2',$1,'Đoàn viên Thử Hai') ON CONFLICT DO NOTHING`, [ORG]);
  // Quản trị viên được tạo bằng chính script create-admin (tên đăng nhập TKBTCĐTBL, không email).
  const r = spawnSync('node', ['scripts/create-admin.js'], { env: { ...env, ADMIN_ORG_ID: ORG, ADMIN_USERNAME, ADMIN_PASSWORD }, encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr || r.stdout);
  const h = await bcrypt.hash('Mat-khau-doan-vien-thu-1', 10);
  const mk = async (username, role, member) => (await pool.query(
    `INSERT INTO users(organization_id,member_id,username,username_key,password_hash,role,status) VALUES($1,$2,$3,$4,$5,$6,'ACTIVE') RETURNING id`,
    [ORG, member, username, username.toLocaleLowerCase('vi'), h, role])).rows[0].id;
  ids.admin = (await pool.query('SELECT id FROM users WHERE username_key=$1', [ADMIN_USERNAME.toLocaleLowerCase('vi')])).rows[0].id;
  ids.member = await mk('doanvien.thu', 'Đoàn viên', 'tv1');
  ids.deputy = await mk('phobithu.thu', 'Phó Bí thư', 'pb1');
  ids.locked = await mk('khoa.thu', 'Đoàn viên', 'lk1');
  ids.throttle = await mk('khoatam.thu', 'Đoàn viên', 'lo1');
  ids.other = await mk('nguoikhac.thu', 'Đoàn viên', 'lo2');
  server = spawn('node', ['src/server.js'], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  await new Promise((ok, bad) => {
    const t = setTimeout(() => bad(new Error('Máy chủ không khởi động')), 15000);
    server.stdout.on('data', d => { if (String(d).includes('listening')) { clearTimeout(t); ok(); } });
    server.on('exit', c => bad(new Error('Máy chủ thoát sớm: ' + c)));
  });
});
after(async () => {
  if (server) server.kill();
  if (pool) { await pool.query('DELETE FROM auth_sessions WHERE organization_id=$1', [ORG]); await pool.end(); }
});

const PROTECTED = [
  ['GET', '/api/auth/me'], ['POST', '/api/auth/logout'],
  ['GET', '/api/qr/sessions'], ['POST', '/api/qr/sessions'], ['POST', '/api/qr/check-in'], ['GET', '/api/qr/my-attendance'],
  ['GET', '/api/qr/activities/x/attendance'], ['POST', '/api/qr/activities/x/manual'], ['POST', '/api/qr/activities/x/lock'],
  ['POST', '/api/qr/sessions/x/rotate'], ['POST', '/api/qr/sessions/x/close'],
  ['GET', '/api/certificates'], ['GET', '/api/certificates/mine'], ['POST', '/api/certificates'], ['POST', '/api/certificates/x/revoke'],
  ['GET', '/api/admin/organizations/tree'], ['POST', '/api/admin/organizations'], ['PATCH', '/api/admin/organizations/x'],
  ['GET', '/api/admin/permissions/grants'], ['POST', '/api/admin/permissions/grants'], ['POST', '/api/admin/permissions/grants/x/revoke']
];

test('Khách (không token) bị từ chối 401 ở MỌI route nội bộ', { skip }, async () => {
  for (const [m, p] of PROTECTED) {
    const r = await call(m, p, { body: m === 'GET' ? undefined : {} });
    assert.equal(r.status, 401, `${m} ${p} phải 401 nhưng nhận ${r.status}`);
  }
});
test('Route công khai chỉ trả dữ liệu tối thiểu và không cần đăng nhập', { skip }, async () => {
  assert.equal((await call('GET', '/health')).status, 200);
  assert.equal((await call('GET', '/api/qr/public/' + 'a'.repeat(40))).status, 410);
  assert.equal((await call('GET', '/api/certificates/public/verify/' + 'a'.repeat(50))).status, 404);
});
test('Token rác / chữ ký sai / alg=none bị từ chối', { skip }, async () => {
  assert.equal((await call('GET', '/api/auth/me', { token: 'abc.def.ghi' })).status, 401);
  const forged = jwt.sign({ org: ORG, role: 'Bí thư', sid: '00000000-0000-0000-0000-000000000000' }, 'sai-khoa', { subject: ids.admin });
  assert.equal((await call('GET', '/api/admin/organizations/tree', { token: forged })).status, 401);
  const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url');
  const none = `${b64({ alg: 'none', typ: 'JWT' })}.${b64({ sub: ids.admin, org: ORG, role: 'Bí thư', sid: 'x' })}.`;
  assert.equal((await call('GET', '/api/auth/me', { token: none })).status, 401);
});

let adminToken;
test('Đăng nhập bằng đúng tên đăng nhập TKBTCĐTBL (không cần/không tự tạo email)', { skip }, async () => {
  const r = await call('POST', '/api/auth/login', { body: { username: ADMIN_USERNAME, password: ADMIN_PASSWORD } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.user.username, 'TKBTCĐTBL');
  assert.equal(r.body.user.email, null, 'không được tự đổi tên đăng nhập thành email');
  assert.equal(r.body.user.role, 'Bí thư');
  adminToken = r.body.token;
  const me = await call('GET', '/api/auth/me', { token: adminToken });
  assert.equal(me.status, 200);
  assert.equal(me.body.user.username, 'TKBTCĐTBL');
  const row = (await pool.query('SELECT username,email FROM users WHERE id=$1', [ids.admin])).rows[0];
  assert.deepEqual(row, { username: 'TKBTCĐTBL', email: null });
});
test('Tên đăng nhập không phân biệt hoa/thường nhưng vẫn là cùng một tài khoản', { skip }, async () => {
  const r = await call('POST', '/api/auth/login', { body: { username: '  tkbtcđtbl ', password: ADMIN_PASSWORD } });
  assert.equal(r.status, 200);
  assert.equal(r.body.user.id, ids.admin);
});
test('Sai mật khẩu, tên không tồn tại, SQL injection: cùng một thông báo 401, không lộ tài khoản có tồn tại', { skip }, async () => {
  const a = await call('POST', '/api/auth/login', { body: { username: ADMIN_USERNAME, password: 'sai-mat-khau' } });
  const b = await call('POST', '/api/auth/login', { body: { username: 'khong.ton.tai', password: 'sai-mat-khau' } });
  const c = await call('POST', '/api/auth/login', { body: { username: "' OR 1=1 --", password: 'x' } });
  for (const r of [a, b, c]) assert.equal(r.status, 401);
  assert.equal(a.body.message, b.body.message);
  assert.equal(a.body.code, b.body.code);
});
test('Tài khoản bị khóa không đăng nhập được', { skip }, async () => {
  await pool.query(`UPDATE users SET status='LOCKED' WHERE id=$1`, [ids.locked]);
  const r = await call('POST', '/api/auth/login', { body: { username: 'khoa.thu', password: 'Mat-khau-doan-vien-thu-1' } });
  assert.equal(r.status, 401);
});

test('Phân quyền do máy chủ quyết định: Đoàn viên bị 403 ở chức năng quản trị', { skip }, async () => {
  const { token } = await sessionFor(ids.member, 'Đoàn viên');
  const denied = [
    ['POST', '/api/qr/sessions', { activityId: 'x', closesAt: new Date(Date.now() + 3600e3).toISOString() }],
    ['GET', '/api/qr/sessions'], ['GET', '/api/qr/activities/x/attendance'], ['POST', '/api/qr/activities/x/manual', {}], ['POST', '/api/qr/activities/x/lock', {}],
    ['GET', '/api/certificates'], ['POST', '/api/certificates', {}], ['POST', '/api/certificates/x/revoke', {}],
    ['GET', '/api/admin/organizations/tree'], ['POST', '/api/admin/organizations', {}], ['GET', '/api/admin/permissions/grants'], ['POST', '/api/admin/permissions/grants', {}]
  ];
  for (const [m, p, body] of denied) { const r = await call(m, p, { token, body }); assert.equal(r.status, 403, `${m} ${p} phải 403 nhưng nhận ${r.status}`); }
  assert.equal((await call('GET', '/api/certificates/mine', { token })).status, 200, 'chứng nhận của chính mình vẫn xem được');
});
test('Phó Bí thư không được tạo phiên QR hay quản trị tổ chức/quyền', { skip }, async () => {
  const { token } = await sessionFor(ids.deputy, 'Phó Bí thư');
  assert.equal((await call('POST', '/api/qr/sessions', { token, body: { activityId: 'x', closesAt: new Date(Date.now() + 3600e3).toISOString() } })).status, 403);
  assert.equal((await call('GET', '/api/admin/permissions/grants', { token })).status, 403);
  assert.equal((await call('POST', '/api/certificates', { token, body: {} })).status, 403);
});
test('Máy chủ dùng vai trò trong CSDL, KHÔNG tin vai trò ghi trong token', { skip }, async () => {
  const { token } = await sessionFor(ids.member, 'Bí thư'); // token ký đúng khóa nhưng tự xưng Bí thư
  assert.equal((await call('GET', '/api/admin/organizations/tree', { token })).status, 403);
  assert.equal((await call('GET', '/api/qr/activities/x/attendance', { token })).status, 403);
});
test('Bí thư (TKBTCĐTBL) được phép vào chức năng quản trị', { skip }, async () => {
  const t = await call('GET', '/api/admin/organizations/tree', { token: adminToken });
  assert.equal(t.status, 200, JSON.stringify(t.body));
  assert.equal((await call('GET', '/api/certificates', { token: adminToken })).status, 200);
});
test('Đăng xuất thu hồi phiên ở máy chủ: token cũ không dùng lại được', { skip }, async () => {
  const { token } = await sessionFor(ids.admin, 'Bí thư');
  assert.equal((await call('GET', '/api/admin/organizations/tree', { token })).status, 200);
  const out = await call('POST', '/api/auth/logout', { token, body: {} });
  assert.equal(out.status, 200);
  for (const [m, p] of [['GET', '/api/auth/me'], ['GET', '/api/admin/organizations/tree'], ['GET', '/api/certificates']])
    assert.equal((await call(m, p, { token })).status, 401, `${p} sau đăng xuất phải 401`);
});
test('Phiên hết hạn / tài khoản bị khóa sau khi đăng nhập: token bị vô hiệu ngay', { skip }, async () => {
  const s1 = await sessionFor(ids.deputy, 'Phó Bí thư');
  await pool.query(`UPDATE auth_sessions SET created_at=now()-interval '2 hours',expires_at=now()-interval '1 minute' WHERE id=$1`, [s1.sid]);
  assert.equal((await call('GET', '/api/auth/me', { token: s1.token })).status, 401);
  const s2 = await sessionFor(ids.member, 'Đoàn viên');
  assert.equal((await call('GET', '/api/auth/me', { token: s2.token })).status, 200);
  await pool.query(`UPDATE users SET status='DISABLED' WHERE id=$1`, [ids.member]);
  assert.equal((await call('GET', '/api/auth/me', { token: s2.token })).status, 401);
  await pool.query(`UPDATE users SET status='ACTIVE' WHERE id=$1`, [ids.member]);
});
test('Bí thư tạo tài khoản đoàn viên: mật khẩu tạm, buộc đổi, đăng nhập được', { skip }, async () => {
  const a = await sessionFor(ids.admin, 'Bí thư');
  const r = await call('POST', '/api/admin/users', { token: a.token, body: { username: NEWUSER, memberId: NEWMEM, fullName: 'Nguyễn Văn An', role: 'Đoàn viên' } });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  assert.ok(r.body.temporaryPassword && r.body.temporaryPassword.length >= 12);
  assert.equal(r.body.user.role, 'Đoàn viên');
  const row = (await pool.query('SELECT organization_id,member_id,must_change_password,created_by FROM users WHERE username_key=$1', [NEWUSER.toLowerCase()])).rows[0];
  assert.deepEqual([row.organization_id, row.member_id, row.must_change_password, row.created_by], [ORG, NEWMEM, true, ids.admin]);
  ids.newUser = (await pool.query('SELECT id FROM users WHERE username_key=$1', [NEWUSER.toLowerCase()])).rows[0].id;
  assert.notEqual((await pool.query('SELECT password_hash FROM users WHERE id=$1', [ids.newUser])).rows[0].password_hash, r.body.temporaryPassword, 'mật khẩu phải được băm');
  const login = await call('POST', '/api/auth/login', { body: { username: NEWUSER.toLowerCase(), password: r.body.temporaryPassword } });
  assert.equal(login.status, 200);
  assert.equal(login.body.user.mustChangePassword, true);
  assert.equal(login.body.user.role, 'Đoàn viên');
  ids.tmpPw = r.body.temporaryPassword;
  // Máy chủ ép đổi mật khẩu tạm: mọi API khác bị 403 cho tới khi đổi.
  assert.equal((await call('GET', '/api/certificates/mine', { token: login.body.token })).status, 403);
  assert.equal((await call('GET', '/api/certificates/mine', { token: login.body.token })).body.code, 'PASSWORD_CHANGE_REQUIRED');
  assert.equal((await call('GET', '/api/auth/me', { token: login.body.token })).status, 200);
  ids.newToken = login.body.token;
});
test('Đổi mật khẩu: sai mật khẩu cũ bị từ chối, đổi thành công gỡ cờ buộc đổi', { skip }, async () => {
  assert.equal((await call('POST', '/api/auth/change-password', { token: ids.newToken, body: { currentPassword: 'sai-sai-sai-sai', newPassword: 'Mat-khau-moi-123456' } })).status, 400);
  assert.equal((await call('POST', '/api/auth/change-password', { token: ids.newToken, body: { currentPassword: ids.tmpPw, newPassword: 'ngan' } })).status, 400);
  assert.equal((await call('POST', '/api/auth/change-password', { token: ids.newToken, body: { currentPassword: ids.tmpPw, newPassword: 'Mat-khau-moi-123456' } })).status, 200);
  const me = await call('GET', '/api/auth/me', { token: ids.newToken });
  assert.equal(me.status, 200); assert.equal(me.body.user.mustChangePassword, false);
  assert.equal((await call('GET', '/api/certificates/mine', { token: ids.newToken })).status, 200, 'sau khi đổi, dùng bình thường');
});
test('Tạo tài khoản: trùng tên/đoàn viên 409; không tạo được Bí thư; dữ liệu sai 400', { skip }, async () => {
  const a = await sessionFor(ids.admin, 'Bí thư');
  const dup = await call('POST', '/api/admin/users', { token: a.token, body: { username: NEWUSER.toUpperCase(), memberId: 'dv-khac-' + RUN, fullName: 'Người Khác' } });
  assert.equal(dup.status, 409);
  const dupMember = await call('POST', '/api/admin/users', { token: a.token, body: { username: 'ten.khac' + RUN, memberId: NEWMEM, fullName: 'Nguyễn Văn An' } });
  assert.equal(dupMember.status, 409);
  assert.equal((await call('POST', '/api/admin/users', { token: a.token, body: { username: 'bithu.gia', memberId: 'dv-x', fullName: 'X', role: 'Bí thư' } })).status, 400, 'không được tạo Bí thư qua API');
  assert.equal((await call('POST', '/api/admin/users', { token: a.token, body: { username: 'a b@c', memberId: 'dv-y', fullName: 'Y' } })).status, 400);
  assert.equal((await call('POST', '/api/admin/users', { token: a.token, body: { username: 'ok.user', memberId: 'dv-z', fullName: 'Z', password: 'ngan' } })).status, 400);
});
test('Chỉ Bí thư quản lý tài khoản: Đoàn viên và Phó Bí thư bị 403, Khách 401', { skip }, async () => {
  const m = await sessionFor(ids.member, 'Đoàn viên'); const d = await sessionFor(ids.deputy, 'Phó Bí thư');
  for (const t of [m.token, d.token]) {
    assert.equal((await call('GET', '/api/admin/users', { token: t })).status, 403);
    assert.equal((await call('POST', '/api/admin/users', { token: t, body: { username: 'hack.user', memberId: 'h1', fullName: 'H' } })).status, 403);
    assert.equal((await call('POST', `/api/admin/users/${ids.newUser}/reset-password`, { token: t, body: {} })).status, 403);
    assert.equal((await call('POST', `/api/admin/users/${ids.newUser}/status`, { token: t, body: { status: 'LOCKED' } })).status, 403);
  }
  assert.equal((await call('GET', '/api/admin/users')).status, 401);
});
test('Bí thư chỉ thấy/sửa tài khoản trong đơn vị của mình', { skip }, async () => {
  await pool.query(`INSERT INTO organizations(id,name) VALUES('V138-KHAC','Đơn vị khác') ON CONFLICT DO NOTHING`);
  const other = (await pool.query(`INSERT INTO users(organization_id,username,username_key,password_hash,role,status) VALUES('V138-KHAC',$1,$1,'x','Đoàn viên','ACTIVE') RETURNING id`, ['nguoi.dv-khac.' + RUN])).rows[0].id;
  const a = await sessionFor(ids.admin, 'Bí thư');
  const list = await call('GET', '/api/admin/users', { token: a.token });
  assert.equal(list.status, 200);
  assert.ok(list.body.users.some(u => u.username === NEWUSER));
  assert.ok(!list.body.users.some(u => u.id === other), 'không được thấy tài khoản đơn vị khác');
  assert.equal((await call('POST', `/api/admin/users/${other}/reset-password`, { token: a.token, body: {} })).status, 404);
  assert.equal((await call('POST', `/api/admin/users/${other}/status`, { token: a.token, body: { status: 'LOCKED' } })).status, 404);
  assert.ok(!JSON.stringify(list.body).includes('password'), 'không trả băm mật khẩu');
});
test('Đặt lại mật khẩu thu hồi phiên cũ; khóa tài khoản chặn đăng nhập; không đụng tới Bí thư', { skip }, async () => {
  const a = await sessionFor(ids.admin, 'Bí thư');
  const reset = await call('POST', `/api/admin/users/${ids.newUser}/reset-password`, { token: a.token, body: {} });
  assert.equal(reset.status, 200); assert.ok(reset.body.temporaryPassword);
  assert.equal((await call('GET', '/api/auth/me', { token: ids.newToken })).status, 401, 'phiên cũ phải bị thu hồi');
  const lock = await call('POST', `/api/admin/users/${ids.newUser}/status`, { token: a.token, body: { status: 'LOCKED' } });
  assert.equal(lock.status, 200);
  assert.equal((await pool.query('SELECT status FROM users WHERE id=$1', [ids.newUser])).rows[0].status, 'LOCKED');
  assert.equal((await call('POST', `/api/admin/users/${ids.admin}/status`, { token: a.token, body: { status: 'LOCKED' } })).status, 403, 'không tự khóa Bí thư');
  assert.equal((await call('POST', `/api/admin/users/${ids.newUser}/status`, { token: a.token, body: { status: 'ACTIVE' } })).status, 200);
  const logs = (await pool.query(`SELECT action FROM audit_logs WHERE organization_id=$1 AND action LIKE 'USER_%'`, [ORG])).rows.map(r => r.action);
  for (const x of ['USER_CREATED', 'USER_PASSWORD_RESET', 'USER_LOCKED', 'USER_UNLOCKED']) assert.ok(logs.includes(x), 'thiếu nhật ký ' + x);
});
const PW = 'Mat-khau-doan-vien-thu-1';
const loginFrom = (ip, username, password) => fetch(BASE + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': ip }, body: JSON.stringify({ username, password }) });
test('Sau reverse proxy: nhiều đoàn viên ở các IP khác nhau đăng nhập ĐÚNG không bị chặn lẫn nhau', { skip }, async () => {
  const statuses = [];
  for (let i = 0; i < 12; i++) statuses.push((await loginFrom(`113.160.1.${i + 1}`, i % 2 ? 'doanvien.thu' : 'phobithu.thu', PW)).status);
  assert.ok(statuses.every(x => x === 200), 'đăng nhập đúng không được đếm vào giới hạn: ' + statuses.join(','));
});
test('Nhập sai nhiều lần chỉ chặn đúng (IP + tên đăng nhập) đó, người khác cùng IP vẫn đăng nhập được', { skip }, async () => {
  const ip = '27.72.5.5'; let blocked = false;
  for (let i = 0; i < 10 && !blocked; i++) blocked = (await loginFrom(ip, 'nguoikhac.thu', 'sai-mat-khau-' + i)).status === 429;
  assert.ok(blocked, 'tên bị đoán sai nhiều lần phải bị chặn 429');
  assert.equal((await loginFrom(ip, 'doanvien.thu', PW)).status, 200, 'đoàn viên khác cùng IP phải đăng nhập được');
});
test('Khóa tạm tài khoản sau 10 lần sai liên tiếp, kể cả khi đoán từ nhiều IP khác nhau; tự mở khi hết hạn', { skip }, async () => {
  for (let i = 0; i < 10; i++) assert.equal((await loginFrom(`14.161.9.${i + 1}`, 'khoatam.thu', 'sai-' + i)).status, 401);
  const locked = await loginFrom('14.161.9.99', 'khoatam.thu', PW);
  assert.equal(locked.status, 401, 'đúng mật khẩu nhưng đang khóa tạm vẫn bị từ chối');
  assert.match((await locked.json()).message, /tạm khóa/);
  const until = (await pool.query('SELECT login_locked_until FROM users WHERE id=$1', [ids.throttle])).rows[0].login_locked_until;
  assert.ok(until && new Date(until) > new Date());
  await pool.query(`UPDATE users SET login_locked_until=now()-interval '1 second' WHERE id=$1`, [ids.throttle]);
  assert.equal((await loginFrom('14.161.9.100', 'khoatam.thu', PW)).status, 200, 'hết thời gian khóa thì đăng nhập lại được');
  assert.equal((await pool.query('SELECT failed_login_count FROM users WHERE id=$1', [ids.throttle])).rows[0].failed_login_count, 0, 'đăng nhập đúng thì xóa bộ đếm sai');
});
test('migrate.js phát hiện migration đã áp dụng bị sửa nội dung', { skip }, async () => {
  const run = () => spawnSync('node', ['scripts/migrate.js'], { env, encoding: 'utf8' });
  assert.equal(run().status, 0);
  await pool.query(`UPDATE schema_migrations SET checksum='00' WHERE name='001_qr_attendance.sql'`);
  const bad = run(); assert.notEqual(bad.status, 0); assert.match(bad.stderr + bad.stdout, /bị SỬA/);
  const { createHash } = await import('node:crypto'); const fs = await import('node:fs');
  const sum = createHash('sha256').update(fs.readFileSync('migrations/001_qr_attendance.sql', 'utf8').replace(/\r\n/g, '\n')).digest('hex');
  await pool.query(`UPDATE schema_migrations SET checksum=$1 WHERE name='001_qr_attendance.sql'`, [sum]);
  assert.equal(run().status, 0);
});
test('Giới hạn tốc độ đăng nhập: bị chặn 429 khi thử sai liên tục', { skip }, async () => {
  let got429 = false;
  for (let i = 0; i < 12 && !got429; i++) {
    const r = await call('POST', '/api/auth/login', { body: { username: ADMIN_USERNAME, password: 'doan-sai-' + i } });
    if (r.status === 429) got429 = true;
  }
  assert.ok(got429, 'phải có phản hồi 429 sau nhiều lần sai');
});
