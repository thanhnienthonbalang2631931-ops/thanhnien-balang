import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const migration=fs.readFileSync(path.join(root,'migrations/002_platform_security.sql'),'utf8');
const auth=fs.readFileSync(path.join(root,'src/routes/auth.js'),'utf8');
const authMw=fs.readFileSync(path.join(root,'src/middleware/auth.js'),'utf8');
const cert=fs.readFileSync(path.join(root,'src/routes/certificates.js'),'utf8');
const perm=fs.readFileSync(path.join(root,'src/middleware/permissions.js'),'utf8');
const server=fs.readFileSync(path.join(root,'src/server.js'),'utf8');

test('migration adds revocable sessions and scoped permission grants',()=>{
  assert.match(migration,/CREATE TABLE IF NOT EXISTS auth_sessions/i);
  assert.match(migration,/revoked_at timestamptz/i);
  assert.match(migration,/CREATE TABLE IF NOT EXISTS user_permission_grants/i);
  assert.match(migration,/data_scope IN \('SELF','UNIT','DESCENDANTS','EXPLICIT'\)/i);
});
test('JWT authentication requires a live server-side session',()=>{
  assert.match(auth,/sid:sessionId/);
  assert.match(authMw,/claims\.sid/);
  assert.match(authMw,/s\.revoked_at IS NULL AND s\.expires_at>now\(\)/);
  assert.match(auth,/router\.post\('\/logout'/);
});
test('password reset stores token hashes, expires tokens, and revokes old sessions',()=>{
  assert.match(auth,/password-reset\/request/);
  assert.match(auth,/hashToken\(token\)/);
  assert.match(auth,/interval '30 minutes'/);
  assert.match(auth,/password-reset\/confirm/);
  assert.match(auth,/UPDATE auth_sessions SET revoked_at=now\(\) WHERE user_id/);
});
test('certificate public verification is a single-token lookup with minimal fields',()=>{
  assert.match(cert,/router\.get\('\/public\/verify\/:token'/);
  assert.match(cert,/WHERE token_hash=\$1 LIMIT 1/);
  assert.match(cert,/recipient_name,certificate_title,issued_on,issuer_name,public_note,status/);
  assert.doesNotMatch(cert,/SELECT \* FROM certificates/);
});
test('certificate issue/revoke and read-all use backend permission middleware',()=>{
  assert.match(cert,/requirePermission\('certificates','issue'/);
  assert.match(cert,/requirePermission\('certificates','revoke'/);
  assert.match(cert,/requirePermission\('certificates','read_all'/);
  assert.match(perm,/user_permission_grants/);
});
test('certificate router is mounted in the API server',()=>{
  assert.match(server,/app\.use\('\/api\/certificates',certificateRoutes\)/);
});
