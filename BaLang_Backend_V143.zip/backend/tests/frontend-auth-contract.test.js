import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../../',import.meta.url);
const html=fs.readFileSync(new URL('../../index.html',import.meta.url),'utf8');
const auth=fs.readFileSync(new URL('../../V138_AUTH_CONTROLS.js',import.meta.url),'utf8');
const server=fs.readFileSync(new URL('../src/server.js',import.meta.url),'utf8');
const admin=fs.readFileSync(new URL('../src/routes/administration.js',import.meta.url),'utf8');
test('legacy role picker is removed from the rendered toolbar',()=>{
  assert.doesNotMatch(html,/<select[^>]+id="rolePicker"/i);
  assert.doesNotMatch(html,/<select[^>]+id="demoMemberPicker"/i);
  assert.match(html,/V138_AUTH_CONTROLS\.js/);
});
test('frontend role defaults to Guest and uses server auth endpoints',()=>{
  assert.match(html,/let currentRole = 'Khách'/);
  assert.match(auth,/\/auth\/login/);
  assert.match(auth,/\/auth\/me/);
  assert.match(auth,/\/auth\/logout/);
  assert.match(auth,/sessionStorage\.setItem\(TOKEN_KEY/);
});
test('public certificate verification is one-token endpoint and returns to Guest',()=>{
  assert.match(auth,/\/certificates\/public\/verify\//);
  assert.match(auth,/toGuest\(/);
  assert.match(auth,/verify-certificate/);
});
test('organization and explicit grant administration routes are mounted',()=>{
  assert.match(server,/administrationRoutes/);
  assert.match(server,/app\.use\('\/api\/admin',administrationRoutes\)/);
  assert.match(admin,/requirePermission\('organizations','manage'\)/);
  assert.match(admin,/requirePermission\('permissions','manage'\)/);
  assert.match(admin,/PERMISSION_REVOKED/);
});
test('permission catalog migration starts from deny-by-default outside Secretary',()=>{
  const migration=fs.readFileSync(new URL('../migrations/003_permission_catalog.sql',import.meta.url),'utf8');
  assert.match(migration,/SELECT 'Bí thư',id,true FROM permissions/);
  assert.match(migration,/SELECT r\.role,p\.id,false/);
  assert.match(migration,/requests' AND p\.action_key IN \('create_own','read_own'\)/);
});
test('explicit grants are bounded to the grantor organization tree',()=>{
  assert.match(admin,/Phạm vi đơn vị ủy quyền vượt ngoài cây đơn vị/);
  assert.match(admin,/Phạm vi hồ sơ ủy quyền có hồ sơ ngoài cây đơn vị/);
  assert.match(admin,/recordIds\.length/);
});

test('V138: nút Đăng nhập/Đăng xuất là phần tử cuối thanh menu và đăng nhập bằng tên đăng nhập',()=>{
  assert.match(auth,/side\.lastElementChild!==dock/);
  assert.match(auth,/v138AuthDock/);
  assert.match(auth,/name=\"username\" type=\"text\"/);
  assert.doesNotMatch(auth,/type=\\?\"email\\?\"[^>]*name=\\?\"username/);
  assert.match(auth,/JSON\.stringify\(\{username,password\}\)/);
});
