BEGIN;
-- Catalog all planned modules/actions centrally. Until a module's API is implemented,
-- these entries are inert: a permission row alone does not create an endpoint.
INSERT INTO permissions(module_key,action_key,description) VALUES
 ('dashboard','read','Xem tổng quan'),
 ('members','read','Xem danh sách đoàn viên'),('members','create','Tạo hồ sơ đoàn viên'),('members','update','Cập nhật hồ sơ đoàn viên'),('members','archive','Lưu trữ hồ sơ đoàn viên'),('members','transfer','Chuyển hồ sơ giữa đơn vị'),
 ('activities','read','Xem hoạt động'),('activities','create','Tạo hoạt động'),('activities','update','Sửa hoạt động'),('activities','delete','Xóa hoạt động'),
 ('tasks','read','Xem nhiệm vụ'),('tasks','create','Giao nhiệm vụ'),('tasks','update','Cập nhật nhiệm vụ'),('tasks','delete','Xóa nhiệm vụ'),
 ('attendance','read','Xem điểm danh'),('attendance','record','Ghi nhận điểm danh'),('attendance','correct','Điều chỉnh điểm danh'),
 ('requests','create_own','Tạo yêu cầu cá nhân'),('requests','read_own','Xem yêu cầu của mình'),('requests','read_all','Xem toàn bộ yêu cầu'),('requests','approve','Duyệt yêu cầu'),
 ('news','read','Xem tin tức'),('news','create','Tạo tin tức'),('news','update','Sửa tin tức'),('news','publish','Xuất bản tin tức'),
 ('tradition','read','Xem sổ truyền thống'),('tradition','update','Cập nhật sổ truyền thống'),
 ('kpi','read','Xem KPI'),('kpi','evaluate','Đánh giá KPI'),
 ('awards','read','Xem khen thưởng'),('awards','manage','Quản lý khen thưởng'),
 ('bch','read','Xem nhân sự BCH'),('bch','manage','Quản lý nhân sự BCH'),
 ('surveys','read','Xem khảo sát'),('surveys','manage','Quản lý khảo sát'),
 ('media','read','Xem thư viện'),('media','upload','Tải tư liệu lên'),('media','approve','Duyệt tư liệu'),('media','delete','Xóa tư liệu'),
 ('accounts','manage','Quản lý tài khoản'),('audit','read','Xem nhật ký thao tác'),('backup','manage','Sao lưu và phục hồi'),
 ('reports','read','Xem báo cáo'),('notifications','read','Xem thông báo'),
 ('periodbooks','read','Xem sổ kỳ ghi'),('periodbooks','manage','Quản lý sổ kỳ ghi')
ON CONFLICT(module_key,action_key) DO NOTHING;
-- Safe defaults: Secretary receives full catalog; all other roles start denied and must receive narrowly scoped explicit grants.
INSERT INTO role_permissions(role,permission_id,allowed)
SELECT 'Bí thư',id,true FROM permissions
ON CONFLICT(role,permission_id) DO UPDATE SET allowed=EXCLUDED.allowed;
INSERT INTO role_permissions(role,permission_id,allowed)
SELECT r.role,p.id,false FROM (VALUES ('Phó Bí thư'),('Ủy viên BCH'),('Đoàn viên')) AS r(role)
CROSS JOIN permissions p
ON CONFLICT(role,permission_id) DO NOTHING;
-- Personal leave requests are the only non-Secretary defaults explicitly established at this stage.
UPDATE role_permissions rp SET allowed=true
FROM permissions p
WHERE rp.permission_id=p.id AND rp.role IN ('Phó Bí thư','Ủy viên BCH','Đoàn viên')
  AND p.module_key='requests' AND p.action_key IN ('create_own','read_own');
COMMIT;
