BEGIN;
-- V139: Bí thư tạo tài khoản cho đoàn viên; mật khẩu tạm buộc đổi ở lần đăng nhập đầu.
ALTER TABLE users ADD COLUMN IF NOT EXISTS must_change_password boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES users(id);
-- Mỗi hồ sơ đoàn viên chỉ có một tài khoản.
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_member ON users(organization_id, member_id) WHERE member_id IS NOT NULL;
COMMIT;
