BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Server-controlled sessions: JWTs are revocable and checked on every request.
CREATE TABLE IF NOT EXISTS auth_sessions (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  organization_id text NOT NULL REFERENCES organizations(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  user_agent text,
  ip_hash text,
  CHECK (expires_at > created_at)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_email_casefold ON users(lower(email));
CREATE INDEX IF NOT EXISTS idx_auth_sessions_user_active ON auth_sessions(user_id, expires_at) WHERE revoked_at IS NULL;

-- Explicit, auditable permissions. Role permissions are defaults; grants are scoped exceptions.
CREATE TABLE IF NOT EXISTS permissions (
  id bigserial PRIMARY KEY,
  module_key text NOT NULL,
  action_key text NOT NULL,
  description text NOT NULL DEFAULT '',
  UNIQUE(module_key, action_key)
);
CREATE TABLE IF NOT EXISTS role_permissions (
  role text NOT NULL CHECK (role IN ('Bí thư','Phó Bí thư','Ủy viên BCH','Đoàn viên')),
  permission_id bigint NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  allowed boolean NOT NULL DEFAULT false,
  PRIMARY KEY(role, permission_id)
);
CREATE TABLE IF NOT EXISTS user_permission_grants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  organization_id text NOT NULL REFERENCES organizations(id),
  module_key text NOT NULL,
  action_key text NOT NULL,
  data_scope text NOT NULL CHECK (data_scope IN ('SELF','UNIT','DESCENDANTS','EXPLICIT')),
  scope_payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_until timestamptz,
  granted_by uuid NOT NULL REFERENCES users(id),
  revoked_at timestamptz,
  revoked_by uuid REFERENCES users(id),
  reason text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (valid_until IS NULL OR valid_until > valid_from)
);
CREATE INDEX IF NOT EXISTS idx_user_grants_active ON user_permission_grants(user_id, organization_id, module_key, action_key) WHERE revoked_at IS NULL;

-- Organization hierarchy is already represented by organizations.parent_id in migration 001.
-- This closure table supports bounded ancestor/descendant authorization without trusting client org IDs.
CREATE TABLE IF NOT EXISTS organization_closure (
  ancestor_id text NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  descendant_id text NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  depth integer NOT NULL CHECK (depth >= 0),
  PRIMARY KEY(ancestor_id, descendant_id)
);
INSERT INTO organization_closure(ancestor_id, descendant_id, depth)
SELECT id, id, 0 FROM organizations ON CONFLICT DO NOTHING;

-- Maintain ancestor/descendant closure when an organization is created or re-parented.
CREATE OR REPLACE FUNCTION rebuild_organization_closure() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP='UPDATE' AND NEW.parent_id IS NOT NULL THEN
    IF NEW.parent_id=NEW.id THEN RAISE EXCEPTION 'Organization cannot be its own parent'; END IF;
    IF EXISTS (
      WITH RECURSIVE descendants(id) AS (
        SELECT NEW.id UNION ALL
        SELECT o.id FROM organizations o JOIN descendants d ON o.parent_id=d.id
      ) SELECT 1 FROM descendants WHERE id=NEW.parent_id
    ) THEN RAISE EXCEPTION 'Organization hierarchy cycle detected'; END IF;
  END IF;
  DELETE FROM organization_closure;
  INSERT INTO organization_closure(ancestor_id,descendant_id,depth)
  WITH RECURSIVE paths(ancestor_id,descendant_id,depth,path) AS (
    SELECT id,id,0,ARRAY[id] FROM organizations
    UNION ALL
    SELECT p.ancestor_id,o.id,p.depth+1,p.path||o.id
    FROM paths p JOIN organizations o ON o.parent_id=p.descendant_id
    WHERE NOT o.id=ANY(p.path)
  ) SELECT ancestor_id,descendant_id,depth FROM paths
    ON CONFLICT(ancestor_id,descendant_id) DO UPDATE SET depth=EXCLUDED.depth;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_rebuild_org_closure ON organizations;
CREATE TRIGGER trg_rebuild_org_closure AFTER INSERT OR UPDATE OF parent_id ON organizations
FOR EACH ROW EXECUTE FUNCTION rebuild_organization_closure();
DELETE FROM organization_closure;
INSERT INTO organization_closure(ancestor_id,descendant_id,depth)
WITH RECURSIVE paths(ancestor_id,descendant_id,depth,path) AS (
  SELECT id,id,0,ARRAY[id] FROM organizations
  UNION ALL
  SELECT p.ancestor_id,o.id,p.depth+1,p.path||o.id
  FROM paths p JOIN organizations o ON o.parent_id=p.descendant_id
  WHERE NOT o.id=ANY(p.path)
) SELECT ancestor_id,descendant_id,depth FROM paths;

-- Password reset is token-hash only. A delivery provider must send the raw token out-of-band.
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  consumed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_password_reset_user ON password_reset_tokens(user_id, expires_at) WHERE consumed_at IS NULL;

-- One opaque token per certificate. Only its hash is stored; public lookup returns one exact record.
CREATE TABLE IF NOT EXISTS certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id text NOT NULL REFERENCES organizations(id),
  member_id text,
  recipient_name text NOT NULL,
  certificate_title text NOT NULL,
  issued_on date NOT NULL,
  issuer_name text NOT NULL,
  public_note text NOT NULL DEFAULT '',
  token_hash text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'ISSUED' CHECK (status IN ('ISSUED','REVOKED')),
  issued_by uuid NOT NULL REFERENCES users(id),
  revoked_by uuid REFERENCES users(id),
  revoked_at timestamptz,
  revoke_reason text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (organization_id, member_id) REFERENCES members(organization_id, id),
  CHECK ((status='ISSUED' AND revoked_at IS NULL) OR (status='REVOKED' AND revoked_at IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS idx_certificates_org_member ON certificates(organization_id, member_id, issued_on DESC);
CREATE INDEX IF NOT EXISTS idx_certificates_status ON certificates(status, issued_on DESC);

-- Minimal permission catalog. The application can extend this catalog via controlled migrations.
INSERT INTO permissions(module_key, action_key, description) VALUES
 ('certificates','issue','Cấp giấy chứng nhận'),
 ('certificates','revoke','Thu hồi giấy chứng nhận'),
 ('certificates','read_all','Xem toàn bộ giấy chứng nhận'),
 ('permissions','manage','Quản lý phân quyền'),
 ('organizations','manage','Quản lý cơ cấu đơn vị')
ON CONFLICT(module_key, action_key) DO NOTHING;
INSERT INTO role_permissions(role, permission_id, allowed)
SELECT 'Bí thư', id, true FROM permissions
ON CONFLICT(role, permission_id) DO UPDATE SET allowed=EXCLUDED.allowed;
INSERT INTO role_permissions(role, permission_id, allowed)
SELECT r.role, p.id, false FROM (VALUES ('Phó Bí thư'),('Ủy viên BCH'),('Đoàn viên')) AS r(role)
CROSS JOIN permissions p
ON CONFLICT(role, permission_id) DO NOTHING;
COMMIT;
