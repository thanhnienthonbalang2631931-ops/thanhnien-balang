BEGIN;
-- Khóa tạm tài khoản khi nhập sai liên tiếp (tự mở sau thời gian chờ; chống dò mật khẩu phân tán nhiều IP).
ALTER TABLE users ADD COLUMN IF NOT EXISTS failed_login_count integer NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS login_locked_until timestamptz;
COMMIT;
