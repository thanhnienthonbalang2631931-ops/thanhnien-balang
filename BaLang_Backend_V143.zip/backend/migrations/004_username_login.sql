BEGIN;
-- V138: đăng nhập bằng tên đăng nhập (ví dụ TKBTCĐTBL). Email trở thành tùy chọn.
-- username        : giữ nguyên cách viết người dùng/quản trị viên đặt.
-- username_key    : dạng chuẩn hóa (NFC + chữ thường) do ứng dụng tính, dùng để so khớp và đảm bảo duy nhất,
--                   không phụ thuộc locale của PostgreSQL (tránh lỗi với chữ Đ/đ).
ALTER TABLE users ADD COLUMN IF NOT EXISTS username text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS username_key text;
ALTER TABLE users ALTER COLUMN email DROP NOT NULL;
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_login_identifier_chk;
ALTER TABLE users ADD CONSTRAINT users_login_identifier_chk
  CHECK (email IS NOT NULL OR username_key IS NOT NULL);
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_username_pair_chk;
ALTER TABLE users ADD CONSTRAINT users_username_pair_chk
  CHECK ((username IS NULL AND username_key IS NULL) OR (username IS NOT NULL AND username_key IS NOT NULL AND length(username)<=100));
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_username_key ON users(username_key) WHERE username_key IS NOT NULL;
COMMIT;
