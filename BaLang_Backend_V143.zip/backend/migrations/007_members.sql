BEGIN;
-- V140 – Hồ sơ đoàn viên là dữ liệu chính thức trên PostgreSQL (thay localStorage).
ALTER TABLE members
  ADD COLUMN IF NOT EXISTS name_key text,
  ADD COLUMN IF NOT EXISTS birth_date date,
  ADD COLUMN IF NOT EXISTS gender text,
  ADD COLUMN IF NOT EXISTS phone text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS address text,
  ADD COLUMN IF NOT EXISTS group_name text,
  ADD COLUMN IF NOT EXISTS union_status text,          -- đã kết nạp / chưa kết nạp
  ADD COLUMN IF NOT EXISTS kind text NOT NULL DEFAULT 'Đoàn viên',
  ADD COLUMN IF NOT EXISTS join_date date,
  ADD COLUMN IF NOT EXISTS admission_decision text,
  ADD COLUMN IF NOT EXISTS admission_place text,
  ADD COLUMN IF NOT EXISTS activity_status text NOT NULL DEFAULT 'Đang sinh hoạt',
  ADD COLUMN IF NOT EXISTS education text,
  ADD COLUMN IF NOT EXISTS occupation text,
  ADD COLUMN IF NOT EXISTS facebook text,
  ADD COLUMN IF NOT EXISTS emergency_contact text,
  ADD COLUMN IF NOT EXISTS emergency_phone text,
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS extra text,
  ADD COLUMN IF NOT EXISTS version integer NOT NULL DEFAULT 1,   -- khóa lạc quan: nhiều người sửa cùng lúc
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS updated_by uuid REFERENCES users(id);
UPDATE members SET name_key=lower(full_name) WHERE name_key IS NULL;
CREATE INDEX IF NOT EXISTS idx_members_dup_name ON members(organization_id,name_key,birth_date);
CREATE INDEX IF NOT EXISTS idx_members_phone ON members(organization_id,phone) WHERE phone IS NOT NULL AND phone<>'';

-- Lịch sử hồ sơ: CHỈ THÊM, không sửa, không xóa (kể cả khi đoàn viên chuyển đi/lưu trữ).
CREATE TABLE IF NOT EXISTS member_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id text NOT NULL REFERENCES organizations(id),
  member_id text NOT NULL REFERENCES members(id),
  event_type text NOT NULL,
  occurred_on date NOT NULL DEFAULT CURRENT_DATE,
  description text NOT NULL DEFAULT '',
  details jsonb NOT NULL DEFAULT '{}',
  created_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_member_history_member ON member_history(organization_id,member_id,created_at DESC);

CREATE TABLE IF NOT EXISTS member_counters (organization_id text PRIMARY KEY REFERENCES organizations(id), last_value integer NOT NULL DEFAULT 0);

CREATE OR REPLACE FUNCTION forbid_history_change() RETURNS trigger AS $$
BEGIN RAISE EXCEPTION 'Lịch sử hồ sơ chỉ được thêm, không được sửa hoặc xóa.' USING ERRCODE='P0001'; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_member_history_immutable ON member_history;
CREATE TRIGGER trg_member_history_immutable BEFORE UPDATE OR DELETE ON member_history FOR EACH ROW EXECUTE FUNCTION forbid_history_change();

CREATE OR REPLACE FUNCTION forbid_member_delete() RETURNS trigger AS $$
BEGIN RAISE EXCEPTION 'Không xóa hồ sơ đoàn viên; hãy lưu trữ (archive) để giữ lịch sử.' USING ERRCODE='P0001'; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_members_no_delete ON members;
CREATE TRIGGER trg_members_no_delete BEFORE DELETE ON members FOR EACH ROW EXECUTE FUNCTION forbid_member_delete();
COMMIT;
