BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS organizations (
  id text PRIMARY KEY,
  name text NOT NULL,
  parent_id text REFERENCES organizations(id),
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','ARCHIVED')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS members (
  id text PRIMARY KEY,
  organization_id text NOT NULL REFERENCES organizations(id),
  full_name text NOT NULL,
  member_status text NOT NULL DEFAULT 'ACTIVE',
  archived_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id, id)
);

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id text NOT NULL REFERENCES organizations(id),
  member_id text,
  email text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('Bí thư','Phó Bí thư','Ủy viên BCH','Đoàn viên')),
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','LOCKED','DISABLED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  last_login_at timestamptz,
  FOREIGN KEY (organization_id, member_id) REFERENCES members(organization_id, id)
);
CREATE INDEX IF NOT EXISTS idx_users_org_member ON users(organization_id, member_id);

CREATE TABLE IF NOT EXISTS activities (
  id text PRIMARY KEY,
  organization_id text NOT NULL REFERENCES organizations(id),
  name text NOT NULL,
  activity_date date NOT NULL,
  start_time time NOT NULL,
  end_time time,
  place text,
  status text NOT NULL DEFAULT 'Đang mở đăng ký',
  required_mode text NOT NULL DEFAULT 'Tất cả đoàn viên phải đi',
  required_member_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  attendance_locked_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id, id)
);
CREATE INDEX IF NOT EXISTS idx_activities_org_date ON activities(organization_id, activity_date DESC);

CREATE TABLE IF NOT EXISTS qr_attendance_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id text NOT NULL REFERENCES organizations(id),
  activity_id text NOT NULL,
  created_by uuid NOT NULL REFERENCES users(id),
  status text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','PAUSED','CLOSED','REVOKED')),
  opens_at timestamptz NOT NULL,
  closes_at timestamptz NOT NULL,
  token_hash text NOT NULL,
  token_expires_at timestamptz NOT NULL,
  token_version integer NOT NULL DEFAULT 1,
  rotation_seconds integer NOT NULL DEFAULT 60 CHECK (rotation_seconds BETWEEN 30 AND 300),
  created_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz,
  closed_by uuid REFERENCES users(id),
  CHECK (closes_at > opens_at),
  FOREIGN KEY (organization_id, activity_id) REFERENCES activities(organization_id, id)
);
CREATE INDEX IF NOT EXISTS idx_qr_sessions_activity ON qr_attendance_sessions(organization_id, activity_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_qr_sessions_status ON qr_attendance_sessions(status, closes_at);

CREATE TABLE IF NOT EXISTS attendance_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id text NOT NULL REFERENCES organizations(id),
  activity_id text NOT NULL,
  session_id uuid REFERENCES qr_attendance_sessions(id),
  member_id text NOT NULL,
  status text NOT NULL CHECK (status IN ('Có mặt đúng giờ','Có mặt muộn','Vắng có phép','Vắng không lý do','Chưa xác nhận')),
  checked_at timestamptz,
  late_minutes integer NOT NULL DEFAULT 0 CHECK (late_minutes >= 0),
  reason text NOT NULL DEFAULT '',
  checkin_method text NOT NULL CHECK (checkin_method IN ('QR','MANUAL')),
  recorded_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (organization_id, member_id) REFERENCES members(organization_id, id),
  UNIQUE (organization_id, activity_id, member_id),
  FOREIGN KEY (organization_id, activity_id) REFERENCES activities(organization_id, id)
);
CREATE INDEX IF NOT EXISTS idx_attendance_activity ON attendance_records(organization_id, activity_id, checked_at);
CREATE INDEX IF NOT EXISTS idx_attendance_member ON attendance_records(organization_id, member_id, checked_at DESC);

CREATE TABLE IF NOT EXISTS audit_logs (
  id bigserial PRIMARY KEY,
  organization_id text NOT NULL REFERENCES organizations(id),
  actor_user_id uuid REFERENCES users(id),
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id text NOT NULL,
  result text NOT NULL DEFAULT 'SUCCESS',
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_org_created ON audit_logs(organization_id, created_at DESC);
COMMIT;
