BEGIN;
-- V143: thêm "Họ tên bố/mẹ" đúng như mẫu hồ sơ hiện tại của Chi đoàn.
ALTER TABLE members ADD COLUMN IF NOT EXISTS parents text;
COMMIT;
