import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { pool } from '../src/db.js';
const here=path.dirname(fileURLToPath(import.meta.url));
try {
  await pool.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`);
  await pool.query('ALTER TABLE schema_migrations ADD COLUMN IF NOT EXISTS checksum text');
  const files=(await fs.readdir(path.join(here,'../migrations'))).filter(x=>/^\d+_.*\.sql$/.test(x)).sort();
  for (const name of files) {
    const sql=await fs.readFile(path.join(here,'../migrations',name),'utf8');
    const sum=createHash('sha256').update(sql.replace(/\r\n/g,'\n')).digest('hex');
    const done=await pool.query('SELECT checksum FROM schema_migrations WHERE name=$1',[name]);
    if(done.rowCount){
      const old=done.rows[0].checksum;
      if(!old){await pool.query('UPDATE schema_migrations SET checksum=$2 WHERE name=$1',[name,sum]);console.log(`${name}: already applied (đã ghi checksum lần đầu)`);}
      else if(old!==sum)throw new Error(`${name} đã được áp dụng nhưng nội dung đã bị SỬA. Không sửa migration cũ: hãy tạo migration mới.`);
      else console.log(`${name}: already applied`);
      continue;
    }
    const client=await pool.connect();
    try {
      await client.query('BEGIN');
      // Migration files contain their own transaction in the legacy package; strip wrappers so ledger and DDL commit atomically.
      const body=sql.replace(/^\s*BEGIN\s*;/i,'').replace(/COMMIT\s*;\s*$/i,'');
      await client.query(body);
      await client.query('INSERT INTO schema_migrations(name,checksum) VALUES($1,$2)',[name,sum]);
      await client.query('COMMIT');
      console.log(`${name}: applied`);
    } catch(error) { await client.query('ROLLBACK').catch(()=>{}); throw error; }
    finally { client.release(); }
  }
} finally { await pool.end(); }
