import bcrypt from 'bcryptjs';
import { pool } from '../src/db.js';
import { cleanUsername, normalizeUsername, isValidUsername } from '../src/username.js';
// Tên đăng nhập quản trị mặc định: TKBTCĐTBL (không phải email). Mật khẩu CHỈ lấy từ biến môi trường, không ghi cứng trong mã.
const {ADMIN_ORG_ID='BA-LANG',ADMIN_ORG_NAME='Chi đoàn thôn Ba Lăng',ADMIN_USERNAME='TKBTCĐTBL',ADMIN_EMAIL='',ADMIN_PASSWORD,ADMIN_RESET_PASSWORD=''}=process.env;
const username=cleanUsername(ADMIN_USERNAME);
if(!isValidUsername(username)){console.error('ADMIN_USERNAME không hợp lệ (2–100 ký tự: chữ, số, . _ -).');process.exit(1);}
if(!ADMIN_PASSWORD||ADMIN_PASSWORD.length<12){console.error('Cần ADMIN_PASSWORD (ít nhất 12 ký tự), truyền qua biến môi trường.');process.exit(1);}
try{
  await pool.query(`INSERT INTO organizations(id,name) VALUES($1,$2) ON CONFLICT(id) DO NOTHING`,[ADMIN_ORG_ID,ADMIN_ORG_NAME]);
  const key=normalizeUsername(username);
  const existing=await pool.query('SELECT id,organization_id FROM users WHERE username_key=$1',[key]);
  if(existing.rowCount && existing.rows[0].organization_id!==ADMIN_ORG_ID)throw new Error('Tên đăng nhập đã được dùng ở một tổ chức khác.');
  const hash=await bcrypt.hash(ADMIN_PASSWORD,12);
  if(!existing.rowCount){
    await pool.query(`INSERT INTO users(organization_id,username,username_key,email,password_hash,role,status) VALUES($1,$2,$3,$4,$5,'Bí thư','ACTIVE')`,
      [ADMIN_ORG_ID,username,key,ADMIN_EMAIL?ADMIN_EMAIL.toLowerCase():null,hash]);
    console.log(`Đã tạo tài khoản quản trị "${username}" (vai trò Bí thư).`);
  } else if(ADMIN_RESET_PASSWORD==='yes'){
    await pool.query(`UPDATE users SET password_hash=$1,status='ACTIVE' WHERE id=$2`,[hash,existing.rows[0].id]);
    await pool.query(`UPDATE auth_sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL`,[existing.rows[0].id]);
    console.log(`Đã đặt lại mật khẩu cho "${username}" và thu hồi mọi phiên đăng nhập cũ.`);
  } else console.log(`Tài khoản "${username}" đã tồn tại; mật khẩu KHÔNG bị ghi đè (đặt ADMIN_RESET_PASSWORD=yes nếu cần đặt lại).`);
}finally{await pool.end();}
