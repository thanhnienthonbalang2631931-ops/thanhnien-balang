import bcrypt from 'bcryptjs';
import { pool } from '../src/db.js';
const {ADMIN_ORG_ID='BA-LANG',USER_EMAIL,USER_PASSWORD,USER_ROLE='Đoàn viên',USER_MEMBER_ID=''}=process.env;
const allowed=['Bí thư','Phó Bí thư','Ủy viên BCH','Đoàn viên'];
if(!USER_EMAIL||!USER_PASSWORD||USER_PASSWORD.length<12||!allowed.includes(USER_ROLE)){
  console.error('Cần USER_EMAIL, USER_PASSWORD (ít nhất 12 ký tự), USER_ROLE hợp lệ; USER_MEMBER_ID nếu là đoàn viên.');process.exit(1);
}
if(USER_ROLE!=='Bí thư'&&!USER_MEMBER_ID){console.error('Tài khoản cán bộ/đoàn viên phải gắn USER_MEMBER_ID.');process.exit(1);}
try{
  if(USER_MEMBER_ID){const m=await pool.query('SELECT id FROM members WHERE id=$1 AND organization_id=$2 AND archived_at IS NULL',[USER_MEMBER_ID,ADMIN_ORG_ID]);if(!m.rowCount)throw new Error('Không tìm thấy hồ sơ đoàn viên tương ứng trong đơn vị.');}
  const existing=await pool.query('SELECT organization_id FROM users WHERE lower(email)=lower($1)',[USER_EMAIL]);
  if(existing.rowCount && existing.rows[0].organization_id!==ADMIN_ORG_ID)throw new Error('Email đã được sử dụng ở một tổ chức khác; không tự động chuyển tài khoản giữa các đơn vị.');
  const hash=await bcrypt.hash(USER_PASSWORD,12);
  await pool.query(`INSERT INTO users(organization_id,member_id,email,password_hash,role,status) VALUES($1,$2,$3,$4,$5,'ACTIVE') ON CONFLICT(email) DO UPDATE SET member_id=EXCLUDED.member_id,password_hash=EXCLUDED.password_hash,role=EXCLUDED.role,status='ACTIVE'`,[ADMIN_ORG_ID,USER_MEMBER_ID||null,USER_EMAIL.toLowerCase(),hash,USER_ROLE]);
  console.log(`Đã tạo/cập nhật tài khoản ${USER_EMAIL} với vai trò ${USER_ROLE}.`);
}finally{await pool.end();}
