import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';
import { requirePermission, hasDataScopeAccess } from '../middleware/permissions.js';

const router = Router();
router.use(requireAuth);

// ---------- Ánh xạ trường & kiểm tra dữ liệu ----------
const COLS = { parents:'parents', fullName:'full_name', birthDate:'birth_date', gender:'gender', phone:'phone', email:'email', address:'address', groupName:'group_name',
  unionStatus:'union_status', kind:'kind', joinDate:'join_date', admissionDecision:'admission_decision', admissionPlace:'admission_place',
  activityStatus:'activity_status', education:'education', occupation:'occupation', facebook:'facebook', emergencyContact:'emergency_contact',
  emergencyPhone:'emergency_phone', notes:'notes', extra:'extra' };
// Trạng thái sinh hoạt: đúng bộ giá trị Chi đoàn đang dùng trên trang Đoàn viên.
const ACTIVITY = ['Đang sinh hoạt','Học tập/làm việc xa','Chuyển sinh hoạt','Trưởng thành Đoàn','Không còn sinh hoạt','Chờ bổ sung'];
const txt = n => z.string().trim().max(n).optional().nullable().transform(v => (v === '' ? null : v));
const dateStr = z.string().trim().regex(/^\d{4}-\d{2}-\d{2}$/, 'Ngày phải có dạng YYYY-MM-DD.').refine(v => !Number.isNaN(Date.parse(v)), 'Ngày không hợp lệ.').optional().nullable().or(z.literal('').transform(() => null));
const fields = {
  fullName: z.string().trim().min(2, 'Họ tên quá ngắn.').max(200), birthDate: dateStr, gender: z.enum(['Nam','Nữ','Khác']).optional().nullable(),
  phone: z.string().trim().regex(/^[0-9+\s.-]{8,20}$/, 'Số điện thoại không hợp lệ.').optional().nullable().or(z.literal('').transform(() => null)),
  email: z.string().trim().email().max(254).optional().nullable().or(z.literal('').transform(() => null)),
  parents: txt(200), address: txt(300), groupName: txt(100), unionStatus: txt(60), kind: z.enum(['Đoàn viên','Thanh niên','Đoàn viên học đại học','Đoàn viên đi làm']).optional(),
  joinDate: dateStr, admissionDecision: txt(200), admissionPlace: txt(200), activityStatus: z.enum(ACTIVITY).optional(),
  education: txt(200), occupation: txt(200), facebook: txt(300), emergencyContact: txt(200),
  emergencyPhone: z.string().trim().regex(/^[0-9+\s.-]{8,20}$/).optional().nullable().or(z.literal('').transform(() => null)), notes: txt(2000), extra: txt(2000)
};
const createSchema = z.object({ ...fields, confirmNotDuplicate: z.boolean().optional() }).strict();
const patchSchema = z.object({ ...Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, v.optional()])), expectedVersion: z.number().int().min(1) }).strict();

const nameKey = s => String(s ?? '').normalize('NFC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('vi');
const memberStatusOf = a => (a === 'Đang sinh hoạt' ? 'ACTIVE' : 'INACTIVE');   // QR điểm danh chỉ nhận ACTIVE
const view = r => ({ id: r.id, organizationId: r.organization_id, fullName: r.full_name, birthDate: r.birth_date && r.birth_date.toISOString?.().slice(0, 10) || r.birth_date,
  gender: r.gender, parents: r.parents, phone: r.phone, email: r.email, address: r.address, groupName: r.group_name, unionStatus: r.union_status, kind: r.kind,
  joinDate: r.join_date && r.join_date.toISOString?.().slice(0, 10) || r.join_date, admissionDecision: r.admission_decision, admissionPlace: r.admission_place,
  activityStatus: r.activity_status, education: r.education, occupation: r.occupation, facebook: r.facebook, emergencyContact: r.emergency_contact,
  emergencyPhone: r.emergency_phone, notes: r.notes, extra: r.extra, archived: !!r.archived_at, version: r.version, updatedAt: r.updated_at, createdAt: r.created_at });
const history = async (db, user, memberId, type, description, details = {}, on) =>
  db.query(`INSERT INTO member_history(organization_id,member_id,event_type,occurred_on,description,details,created_by) VALUES($1,$2,$3,COALESCE($4::date,CURRENT_DATE),$5,$6,$7)`,
    [user.organization_id, memberId, type, on || null, description, JSON.stringify(details), user.id]);
const audit = (db, user, action, id, details = {}) => db.query(
  `INSERT INTO audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,details) VALUES($1,$2,$3,'MEMBER',$4,$5)`, [user.organization_id, user.id, action, String(id), JSON.stringify(details)]);
const scoped = async (req, row) => hasDataScopeAccess(req, { organizationId: row.organization_id, memberId: row.id, recordId: row.id });
const toDb = input => Object.fromEntries(Object.entries(input).filter(([k]) => COLS[k]).map(([k, v]) => [COLS[k], v ?? null]));

// ---------- Hồ sơ của chính mình (mọi tài khoản đã đăng nhập) ----------
router.get('/me', async (req, res, next) => { try {
  if (!req.user.member_id) return res.status(404).json({ ok: false, code: 'NO_MEMBER', message: 'Tài khoản này chưa gắn hồ sơ đoàn viên.' });
  const { rows } = await pool.query('SELECT * FROM members WHERE id=$1 AND organization_id=$2', [req.user.member_id, req.user.organization_id]);
  if (!rows[0]) return res.status(404).json({ ok: false, code: 'NOT_FOUND', message: 'Không tìm thấy hồ sơ.' });
  res.json({ ok: true, member: view(rows[0]) });
} catch (e) { next(e); } });

// ---------- Danh sách / chi tiết ----------
router.get('/', requirePermission('members', 'read'), async (req, res, next) => { try {
  const q = z.object({ q: z.string().trim().max(100).optional(), status: z.enum(ACTIVITY).optional(), kind: z.string().max(60).optional(),
    archived: z.enum(['true', 'false']).default('false'), limit: z.coerce.number().int().min(1).max(200).default(50), offset: z.coerce.number().int().min(0).default(0) }).parse(req.query);
  const params = [req.user.organization_id, q.archived === 'true']; let where = `organization_id=$1 AND (archived_at IS NOT NULL)=$2`;
  if (q.q) { params.push('%' + nameKey(q.q).replace(/[%_\\]/g, '\\$&') + '%'); where += ` AND (name_key LIKE $${params.length} OR id ILIKE $${params.length} OR phone LIKE $${params.length})`; }
  if (q.status) { params.push(q.status); where += ` AND activity_status=$${params.length}`; }
  if (q.kind) { params.push(q.kind); where += ` AND kind=$${params.length}`; }
  const total = (await pool.query(`SELECT count(*)::int n FROM members WHERE ${where}`, params)).rows[0].n;
  params.push(q.limit, q.offset);
  const { rows } = await pool.query(`SELECT * FROM members WHERE ${where} ORDER BY full_name,id LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
  const out = []; for (const r of rows) if (await scoped(req, r)) out.push(view(r));
  res.json({ ok: true, total, members: out });
} catch (e) { next(e); } });

async function loadScoped(req, res) {
  const { rows } = await pool.query('SELECT * FROM members WHERE id=$1 AND organization_id=$2', [req.params.id, req.user.organization_id]);
  if (!rows[0] || !(await scoped(req, rows[0]))) { res.status(404).json({ ok: false, code: 'NOT_FOUND', message: 'Không tìm thấy hồ sơ đoàn viên.' }); return null; }
  return rows[0];
}
router.get('/:id', requirePermission('members', 'read'), async (req, res, next) => { try { const m = await loadScoped(req, res); if (m) res.json({ ok: true, member: view(m) }); } catch (e) { next(e); } });
router.get('/:id/history', requirePermission('members', 'read'), async (req, res, next) => { try {
  const m = await loadScoped(req, res); if (!m) return;
  const { rows } = await pool.query(`SELECT h.id,h.event_type,h.occurred_on,h.description,h.details,h.created_at,u.username AS by FROM member_history h LEFT JOIN users u ON u.id=h.created_by
    WHERE h.organization_id=$1 AND h.member_id=$2 ORDER BY h.created_at DESC,h.id`, [req.user.organization_id, m.id]);
  res.json({ ok: true, history: rows.map(r => ({ id: r.id, type: r.event_type, date: r.occurred_on.toISOString().slice(0, 10), description: r.description, details: r.details, by: r.by, at: r.created_at })) });
} catch (e) { next(e); } });

// ---------- Tạo hồ sơ (mã duy nhất, phát hiện trùng) ----------
async function findDuplicates(db, org, key, birth, phone, excludeId) {
  const { rows } = await db.query(`SELECT id,full_name,birth_date,phone FROM members WHERE organization_id=$1 AND archived_at IS NULL AND ($5::text IS NULL OR id<>$5)
    AND ((name_key=$2 AND ($3::date IS NULL OR birth_date IS NULL OR birth_date=$3::date)) OR ($4::text IS NOT NULL AND phone=$4::text)) LIMIT 5`, [org, key, birth || null, phone || null, excludeId || null]);
  return rows.map(r => ({ id: r.id, fullName: r.full_name, birthDate: r.birth_date && r.birth_date.toISOString().slice(0, 10), phone: r.phone }));
}
router.post('/', requirePermission('members', 'create'), async (req, res, next) => {
  const client = await pool.connect();
  try {
    const input = createSchema.parse(req.body); const org = req.user.organization_id;
    const key = nameKey(input.fullName);
    if (!input.confirmNotDuplicate) {
      const dups = await findDuplicates(client, org, key, input.birthDate, input.phone);
      if (dups.length) return res.status(409).json({ ok: false, code: 'DUPLICATE_CANDIDATE', message: 'Có hồ sơ có thể trùng. Kiểm tra rồi xác nhận nếu đây là người khác.', candidates: dups });
    }
    await client.query('BEGIN');
    const n = (await client.query(`INSERT INTO member_counters(organization_id,last_value) VALUES($1,1) ON CONFLICT(organization_id) DO UPDATE SET last_value=member_counters.last_value+1 RETURNING last_value`, [org])).rows[0].last_value;
    const id = `DV${String(n).padStart(4, '0')}-${org}`.slice(0, 60);
    const data = { ...toDb(input), name_key: key, member_status: memberStatusOf(input.activityStatus ?? 'Đang sinh hoạt'), updated_by: req.user.id };
    const cols = ['id', 'organization_id', ...Object.keys(data)]; const vals = [id, org, ...Object.values(data)];
    const { rows } = await client.query(`INSERT INTO members(${cols.join(',')}) VALUES(${cols.map((_, i) => '$' + (i + 1)).join(',')}) RETURNING *`, vals);
    await history(client, req.user, id, 'Tạo hồ sơ', 'Khởi tạo hồ sơ đoàn viên/thanh niên');
    await audit(client, req.user, 'MEMBER_CREATED', id, { fullName: input.fullName });
    await client.query('COMMIT');
    res.status(201).json({ ok: true, member: view(rows[0]) });
  } catch (e) { await client.query('ROLLBACK').catch(() => {}); next(e); } finally { client.release(); }
});

// ---------- Sửa hồ sơ: khóa lạc quan + ghi lịch sử thay đổi ----------
router.patch('/:id', requirePermission('members', 'update'), async (req, res, next) => {
  const client = await pool.connect();
  try {
    const input = patchSchema.parse(req.body); const { expectedVersion, ...changes } = input;
    await client.query('BEGIN');
    const cur = (await client.query('SELECT * FROM members WHERE id=$1 AND organization_id=$2 FOR UPDATE', [req.params.id, req.user.organization_id])).rows[0];
    if (!cur || !(await scoped(req, cur))) { await client.query('ROLLBACK'); return res.status(404).json({ ok: false, code: 'NOT_FOUND', message: 'Không tìm thấy hồ sơ đoàn viên.' }); }
    if (cur.archived_at) { await client.query('ROLLBACK'); return res.status(409).json({ ok: false, code: 'ARCHIVED', message: 'Hồ sơ đã lưu trữ, không sửa được.' }); }
    if (cur.version !== expectedVersion) { await client.query('ROLLBACK'); return res.status(409).json({ ok: false, code: 'VERSION_CONFLICT', message: 'Hồ sơ vừa được người khác cập nhật. Hãy tải lại rồi sửa tiếp.', currentVersion: cur.version, member: view(cur) }); }
    const data = toDb(changes); const diff = {};
    const same = (a, b) => String(a instanceof Date ? a.toISOString().slice(0, 10) : a ?? '') === String(b ?? '');
    for (const [col, v] of Object.entries(data)) if (!same(cur[col], v)) diff[col] = { from: cur[col] instanceof Date ? cur[col].toISOString().slice(0, 10) : cur[col], to: v };
    if (!Object.keys(diff).length) { await client.query('ROLLBACK'); return res.json({ ok: true, unchanged: true, member: view(cur) }); }
    const set = { ...Object.fromEntries(Object.keys(diff).map(c => [c, data[c]])), updated_by: req.user.id };
    if (diff.full_name) set.name_key = nameKey(data.full_name);
    if (diff.activity_status) set.member_status = memberStatusOf(data.activity_status);
    const keys = Object.keys(set);
    const { rows } = await client.query(`UPDATE members SET ${keys.map((k, i) => `${k}=$${i + 3}`).join(',')},version=version+1,updated_at=now() WHERE id=$1 AND organization_id=$2 RETURNING *`,
      [cur.id, cur.organization_id, ...keys.map(k => set[k])]);
    await history(client, req.user, cur.id, diff.activity_status ? 'Đổi trạng thái sinh hoạt' : 'Cập nhật hồ sơ', 'Cập nhật: ' + Object.keys(diff).join(', '), { changes: diff });
    await audit(client, req.user, 'MEMBER_UPDATED', cur.id, { fields: Object.keys(diff) });
    await client.query('COMMIT');
    res.json({ ok: true, member: view(rows[0]) });
  } catch (e) { await client.query('ROLLBACK').catch(() => {}); next(e); } finally { client.release(); }
});

// ---------- Chuyển đến / chuyển đi / ngừng sinh hoạt (không xóa lịch sử) ----------
router.post('/:id/status', requirePermission('members', 'update'), async (req, res, next) => {
  const client = await pool.connect();
  try {
    const b = z.object({ status: z.enum(ACTIVITY), effectiveDate: dateStr, note: z.string().trim().max(500).optional(), destination: z.string().trim().max(200).optional(), expectedVersion: z.number().int().min(1) }).strict().parse(req.body);
    await client.query('BEGIN');
    const cur = (await client.query('SELECT * FROM members WHERE id=$1 AND organization_id=$2 FOR UPDATE', [req.params.id, req.user.organization_id])).rows[0];
    if (!cur || !(await scoped(req, cur))) { await client.query('ROLLBACK'); return res.status(404).json({ ok: false, code: 'NOT_FOUND', message: 'Không tìm thấy hồ sơ đoàn viên.' }); }
    if (cur.version !== b.expectedVersion) { await client.query('ROLLBACK'); return res.status(409).json({ ok: false, code: 'VERSION_CONFLICT', message: 'Hồ sơ vừa được người khác cập nhật. Hãy tải lại.', currentVersion: cur.version }); }
    const { rows } = await client.query(`UPDATE members SET activity_status=$3,member_status=$4,updated_by=$5,version=version+1,updated_at=now() WHERE id=$1 AND organization_id=$2 RETURNING *`,
      [cur.id, cur.organization_id, b.status, memberStatusOf(b.status), req.user.id]);
    await history(client, req.user, cur.id, b.status, b.note || b.status, { from: cur.activity_status, to: b.status, destination: b.destination || null }, b.effectiveDate);
    await audit(client, req.user, 'MEMBER_STATUS_CHANGED', cur.id, { from: cur.activity_status, to: b.status });
    await client.query('COMMIT');
    res.json({ ok: true, member: view(rows[0]) });
  } catch (e) { await client.query('ROLLBACK').catch(() => {}); next(e); } finally { client.release(); }
});

// ---------- Lưu trữ (thay cho xóa); thu hồi quyền truy cập của người đó ----------
router.post('/:id/archive', requirePermission('members', 'archive'), async (req, res, next) => {
  const client = await pool.connect();
  try {
    const b = z.object({ reason: z.string().trim().min(3, 'Cần ghi lý do lưu trữ.').max(500), expectedVersion: z.number().int().min(1) }).strict().parse(req.body);
    await client.query('BEGIN');
    const cur = (await client.query('SELECT * FROM members WHERE id=$1 AND organization_id=$2 FOR UPDATE', [req.params.id, req.user.organization_id])).rows[0];
    if (!cur || !(await scoped(req, cur))) { await client.query('ROLLBACK'); return res.status(404).json({ ok: false, code: 'NOT_FOUND', message: 'Không tìm thấy hồ sơ đoàn viên.' }); }
    if (cur.version !== b.expectedVersion) { await client.query('ROLLBACK'); return res.status(409).json({ ok: false, code: 'VERSION_CONFLICT', message: 'Hồ sơ vừa được người khác cập nhật. Hãy tải lại.', currentVersion: cur.version }); }
    if (cur.archived_at) { await client.query('ROLLBACK'); return res.status(409).json({ ok: false, code: 'ARCHIVED', message: 'Hồ sơ đã được lưu trữ.' }); }
    const own = await client.query(`SELECT 1 FROM users WHERE member_id=$1 AND organization_id=$2 AND id=$3`, [cur.id, cur.organization_id, req.user.id]);
    if (own.rowCount) { await client.query('ROLLBACK'); return res.status(403).json({ ok: false, code: 'SELF_ARCHIVE', message: 'Không thể tự lưu trữ hồ sơ của chính mình.' }); }
    await client.query(`UPDATE members SET archived_at=now(),member_status='INACTIVE',updated_by=$3,version=version+1,updated_at=now() WHERE id=$1 AND organization_id=$2`, [cur.id, cur.organization_id, req.user.id]);
    const locked = await client.query(`UPDATE users SET status='LOCKED' WHERE member_id=$1 AND organization_id=$2 AND role<>'Bí thư' RETURNING id`, [cur.id, cur.organization_id]);
    if (locked.rowCount) await client.query(`UPDATE auth_sessions SET revoked_at=now() WHERE user_id=ANY($1::uuid[]) AND revoked_at IS NULL`, [locked.rows.map(r => r.id)]);
    await history(client, req.user, cur.id, 'Lưu trữ hồ sơ', b.reason, { accountsLocked: locked.rowCount });
    await audit(client, req.user, 'MEMBER_ARCHIVED', cur.id, { reason: b.reason, accountsLocked: locked.rowCount });
    await client.query('COMMIT');
    res.json({ ok: true, message: 'Đã lưu trữ hồ sơ; tài khoản liên quan đã bị khóa và đăng xuất.' });
  } catch (e) { await client.query('ROLLBACK').catch(() => {}); next(e); } finally { client.release(); }
});

// ---------- Nhập hàng loạt từ bản sao lưu cũ (idempotent theo mã hồ sơ) ----------
const importSchema = z.object({ members: z.array(z.object({ id: z.string().trim().max(60).optional(), name: z.string().trim().min(2).max(200) }).passthrough()).min(1).max(500),
  memberHistory: z.array(z.object({ memberId: z.string(), type: z.string().max(100), date: z.string().optional(), description: z.string().max(1000).optional() }).passthrough()).max(5000).optional() });
const okDate = v => (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}/.test(v) && !Number.isNaN(Date.parse(v.slice(0, 10))) ? v.slice(0, 10) : null);
const okPhone = v => (typeof v === 'string' && /^[0-9+\s.-]{8,20}$/.test(v.trim()) ? v.trim() : null);
const clip = (v, n) => (v == null || v === '' ? null : String(v).slice(0, n));
router.post('/import', requirePermission('members', 'create'), async (req, res, next) => {
  const client = await pool.connect();
  try {
    if (req.user.role !== 'Bí thư') return res.status(403).json({ ok: false, code: 'PERMISSION_DENIED', message: 'Chỉ Bí thư được nhập dữ liệu hàng loạt.' });
    const input = importSchema.parse(req.body); const org = req.user.organization_id;
    const report = { created: 0, skippedExisting: 0, rejected: [], warnings: [], historyAdded: 0 };
    await client.query('BEGIN');
    const created = new Set();
    for (const m of input.members) {
      if (!m.id) { // Excel không có cột mã: hệ thống cấp mã mới
        const n = (await client.query(`INSERT INTO member_counters(organization_id,last_value) VALUES($1,1) ON CONFLICT(organization_id) DO UPDATE SET last_value=member_counters.last_value+1 RETURNING last_value`, [org])).rows[0].last_value;
        m.id = `DV${String(n).padStart(4, '0')}-${org}`.slice(0, 60);
      }
      const exists = (await client.query('SELECT organization_id FROM members WHERE id=$1', [m.id])).rows[0];
      if (exists) { if (exists.organization_id !== org) report.rejected.push({ id: m.id, reason: 'Mã hồ sơ đã thuộc đơn vị khác.' }); else report.skippedExisting++; continue; }
      const birth = okDate(m.birth); if (m.birth && !birth) report.warnings.push({ id: m.id, field: 'birth', message: 'Ngày sinh không hợp lệ, để trống.' });
      const act = ACTIVITY.includes(m.status) ? m.status : 'Đang sinh hoạt';
      const phone = okPhone(m.phone); if (m.phone && !phone) report.warnings.push({ id: m.id, field: 'phone', message: 'Số điện thoại không hợp lệ, để trống.' });
      if ((await findDuplicates(client, org, nameKey(m.name), birth, phone, m.id)).length) report.warnings.push({ id: m.id, field: 'name', message: 'Có thể trùng với hồ sơ khác trong đơn vị — cần rà soát.' });
      await client.query(`INSERT INTO members(id,organization_id,full_name,name_key,birth_date,gender,phone,email,address,group_name,union_status,kind,join_date,admission_decision,admission_place,activity_status,member_status,education,occupation,facebook,emergency_contact,emergency_phone,notes,extra,updated_by,parents)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26)`,
        [m.id, org, m.name, nameKey(m.name), birth, ['Nam', 'Nữ', 'Khác'].includes(m.gender) ? m.gender : null, phone, clip(m.email, 254), clip(m.address, 300), clip(m.group, 100), clip(m.joined, 60),
          ['Đoàn viên', 'Thanh niên', 'Đoàn viên học đại học', 'Đoàn viên đi làm'].includes(m.kind) ? m.kind : 'Đoàn viên', okDate(m.joinDate), clip(m.admissionDecision, 200), clip(m.admissionPlace, 200),
          act, memberStatusOf(act), clip(m.education, 200), clip(m.occupation, 200), clip(m.facebook, 300), clip(m.emergencyContact, 200), okPhone(m.emergencyPhone), clip(m.notes, 2000), clip(m.extra, 2000), req.user.id, clip(m.parents, 200)]);
      created.add(m.id); report.created++;
    }
    for (const h of input.memberHistory || []) {
      if (!created.has(h.memberId)) continue; // chỉ thêm lịch sử cho hồ sơ vừa tạo, tránh nhân đôi khi nhập lại
      await history(client, req.user, h.memberId, h.type, h.description || h.type, { imported: true }, okDate(h.date)); report.historyAdded++;
    }
    await audit(client, req.user, 'MEMBERS_IMPORTED', 'bulk', { created: report.created, skipped: report.skippedExisting, rejected: report.rejected.length });
    await client.query('COMMIT');
    res.status(201).json({ ok: true, report });
  } catch (e) { await client.query('ROLLBACK').catch(() => {}); next(e); } finally { client.release(); }
});

export default router;
