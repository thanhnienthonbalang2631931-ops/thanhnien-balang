import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import bcrypt from 'bcryptjs';
import { randomBytes } from 'node:crypto';
import { requireAuth, allowRoles } from '../middleware/auth.js';
import { cleanUsername, normalizeUsername, isValidUsername } from '../username.js';
import { requirePermission } from '../middleware/permissions.js';

const router=Router();
router.use(requireAuth);
const orgIdSchema=z.string().trim().min(2).max(80).regex(/^[A-Za-z0-9][A-Za-z0-9._-]*$/);
const grantSchema=z.object({
  userId:z.string().uuid(),moduleKey:z.string().trim().min(2).max(80),actionKey:z.string().trim().min(2).max(80),
  dataScope:z.enum(['SELF','UNIT','DESCENDANTS','EXPLICIT']),scopePayload:z.record(z.string(),z.unknown()).default({}),
  validFrom:z.string().datetime().optional(),validUntil:z.string().datetime().nullable().optional(),reason:z.string().trim().min(5).max(500)
}).refine(x=>!x.validUntil||!x.validFrom||new Date(x.validUntil)>new Date(x.validFrom),{message:'Thời hạn kết thúc phải sau thời điểm bắt đầu.'});
const audit=async(client,user,action,type,id,details={})=>client.query(
  `INSERT INTO audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,details) VALUES($1,$2,$3,$4,$5,$6)`,
  [user.organization_id,user.id,action,type,String(id),JSON.stringify(details)]
);

router.get('/organizations/tree',requirePermission('organizations','manage'),async(req,res,next)=>{
  try{const {rows}=await pool.query(`SELECT o.id,o.name,o.parent_id,o.status,c.depth FROM organization_closure c JOIN organizations o ON o.id=c.descendant_id WHERE c.ancestor_id=$1 ORDER BY c.depth,o.name`,[req.user.organization_id]);res.json({ok:true,organizations:rows});}catch(e){next(e);}
});
router.post('/organizations',requirePermission('organizations','manage'),async(req,res,next)=>{
  const schema=z.object({id:orgIdSchema,name:z.string().trim().min(2).max(200),parentId:orgIdSchema.optional()});
  try{
    const input=schema.parse(req.body);const parent=input.parentId||req.user.organization_id;
    const allowed=await pool.query('SELECT 1 FROM organization_closure WHERE ancestor_id=$1 AND descendant_id=$2',[req.user.organization_id,parent]);
    if(!allowed.rowCount)return res.status(403).json({ok:false,message:'Chỉ được tạo đơn vị trực thuộc phạm vi quản lý của tài khoản.'});
    const {rows}=await pool.query(`INSERT INTO organizations(id,name,parent_id) VALUES($1,$2,$3) RETURNING id,name,parent_id,status`,[input.id,input.name,parent]);
    await audit(pool,req.user,'ORGANIZATION_CREATED','ORGANIZATION',input.id,{parentId:parent});res.status(201).json({ok:true,organization:rows[0]});
  }catch(e){next(e);}
});
router.patch('/organizations/:id',requirePermission('organizations','manage'),async(req,res,next)=>{
  const schema=z.object({name:z.string().trim().min(2).max(200).optional(),status:z.enum(['ACTIVE','ARCHIVED']).optional()}).refine(x=>Object.keys(x).length>0);
  try{
    const input=schema.parse(req.body);const scope=await pool.query('SELECT 1 FROM organization_closure WHERE ancestor_id=$1 AND descendant_id=$2',[req.user.organization_id,req.params.id]);
    if(!scope.rowCount)return res.status(404).json({ok:false,message:'Không tìm thấy đơn vị trong phạm vi quản lý.'});
    const {rows}=await pool.query(`UPDATE organizations SET name=COALESCE($1,name),status=COALESCE($2,status) WHERE id=$3 RETURNING id,name,parent_id,status`,[input.name??null,input.status??null,req.params.id]);
    await audit(pool,req.user,'ORGANIZATION_UPDATED','ORGANIZATION',req.params.id,input);res.json({ok:true,organization:rows[0]});
  }catch(e){next(e);}
});

router.get('/permissions/grants',requirePermission('permissions','manage'),async(req,res,next)=>{
  try{
    const [users,grants]=await Promise.all([
      pool.query(`SELECT u.id,u.email,u.role,u.member_id,m.full_name AS member_name,u.status FROM users u LEFT JOIN members m ON m.id=u.member_id AND m.organization_id=u.organization_id WHERE u.organization_id=$1 ORDER BY u.role,u.email`,[req.user.organization_id]),
      pool.query(`SELECT g.id,g.user_id,u.email,g.module_key,g.action_key,g.data_scope,g.scope_payload,g.valid_from,g.valid_until,g.reason,g.created_at,g.revoked_at FROM user_permission_grants g JOIN users u ON u.id=g.user_id WHERE g.organization_id=$1 ORDER BY g.created_at DESC LIMIT 1000`,[req.user.organization_id])
    ]);res.json({ok:true,users:users.rows,grants:grants.rows});
  }catch(e){next(e);}
});
router.post('/permissions/grants',requirePermission('permissions','manage'),async(req,res,next)=>{
  const client=await pool.connect();
  try{
    const input=grantSchema.parse(req.body);
    // High-risk domains remain Secretary-only and cannot be delegated.
    if(['finance','certificates'].includes(input.moduleKey))return res.status(403).json({ok:false,message:'Phân hệ này không được ủy quyền theo chính sách hiện hành.'});
    const user=await client.query(`SELECT id FROM users WHERE id=$1 AND organization_id=$2 AND status='ACTIVE' AND role<>'Bí thư'`,[input.userId,req.user.organization_id]);
    if(!user.rowCount)return res.status(400).json({ok:false,message:'Tài khoản nhận quyền không hợp lệ hoặc không thuộc đơn vị.'});
    const perm=await client.query('SELECT 1 FROM permissions WHERE module_key=$1 AND action_key=$2',[input.moduleKey,input.actionKey]);
    if(!perm.rowCount)return res.status(400).json({ok:false,message:'Quyền yêu cầu chưa có trong danh mục quyền được quản trị.'});
    if(input.dataScope==='EXPLICIT'){
      const orgIds=Array.isArray(input.scopePayload.organizationIds)?input.scopePayload.organizationIds:[];
      const memberIds=Array.isArray(input.scopePayload.memberIds)?input.scopePayload.memberIds:[];
      const recordIds=Array.isArray(input.scopePayload.recordIds)?input.scopePayload.recordIds:[];
      if(recordIds.length)return res.status(400).json({ok:false,message:'Phạm vi theo mã bản ghi chưa được hỗ trợ; chỉ dùng đơn vị hoặc hồ sơ đoàn viên.'});
      if(orgIds.length){const scoped=await client.query('SELECT count(*)::int AS n FROM organization_closure WHERE ancestor_id=$1 AND descendant_id=ANY($2::text[])',[req.user.organization_id,orgIds]);if(scoped.rows[0].n!==orgIds.length)return res.status(403).json({ok:false,message:'Phạm vi đơn vị ủy quyền vượt ngoài cây đơn vị được quản lý.'});}
      if(memberIds.length){const scoped=await client.query(`SELECT count(*)::int AS n FROM members m WHERE m.id=ANY($1::text[]) AND EXISTS(SELECT 1 FROM organization_closure c WHERE c.ancestor_id=$2 AND c.descendant_id=m.organization_id)`,[memberIds,req.user.organization_id]);if(scoped.rows[0].n!==memberIds.length)return res.status(403).json({ok:false,message:'Phạm vi hồ sơ ủy quyền có hồ sơ ngoài cây đơn vị được quản lý.'});}
      if(!orgIds.length&&!memberIds.length)return res.status(400).json({ok:false,message:'Phạm vi EXPLICIT phải chỉ rõ organizationIds hoặc memberIds.'});
    }
    await client.query('BEGIN');
    const {rows}=await client.query(`INSERT INTO user_permission_grants(user_id,organization_id,module_key,action_key,data_scope,scope_payload,valid_from,valid_until,granted_by,reason)
      VALUES($1,$2,$3,$4,$5,$6,COALESCE($7::timestamptz,now()),$8,$9,$10)
      RETURNING id,user_id,module_key,action_key,data_scope,scope_payload,valid_from,valid_until,reason`,
      [input.userId,req.user.organization_id,input.moduleKey,input.actionKey,input.dataScope,JSON.stringify(input.scopePayload),input.validFrom||null,input.validUntil||null,req.user.id,input.reason]);
    await audit(client,req.user,'PERMISSION_GRANTED','PERMISSION_GRANT',rows[0].id,{userId:input.userId,moduleKey:input.moduleKey,actionKey:input.actionKey,dataScope:input.dataScope,reason:input.reason});
    await client.query('COMMIT');res.status(201).json({ok:true,grant:rows[0]});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});next(e);}finally{client.release();}
});
router.post('/permissions/grants/:id/revoke',requirePermission('permissions','manage'),async(req,res,next)=>{
  const client=await pool.connect();
  try{
    await client.query('BEGIN');const {rows}=await client.query(`UPDATE user_permission_grants SET revoked_at=now(),revoked_by=$1 WHERE id=$2 AND organization_id=$3 AND revoked_at IS NULL RETURNING id,user_id,module_key,action_key`,[req.user.id,req.params.id,req.user.organization_id]);
    if(!rows[0]){await client.query('ROLLBACK');return res.status(404).json({ok:false,message:'Không tìm thấy quyền ủy nhiệm còn hiệu lực.'});}
    await audit(client,req.user,'PERMISSION_REVOKED','PERMISSION_GRANT',rows[0].id,rows[0]);await client.query('COMMIT');res.json({ok:true,grant:rows[0]});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});next(e);}finally{client.release();}
});

// ===== Quản lý tài khoản: CHỈ Bí thư, luôn trong phạm vi đơn vị của Bí thư =====
const secretaryOnly=allowRoles('Bí thư');
const ASSIGNABLE=['Phó Bí thư','Ủy viên BCH','Đoàn viên'];
const tempPassword=()=>{const c='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';const b=randomBytes(14);return Array.from(b,x=>c[x%c.length]).join('');};
const pwSchema=z.string().min(12,'Mật khẩu phải có ít nhất 12 ký tự.').max(200);
const createUserSchema=z.object({
  username:z.string().trim().min(2).max(100),
  role:z.enum(ASSIGNABLE).default('Đoàn viên'),
  memberId:z.string().trim().min(1).max(100),
  fullName:z.string().trim().min(1).max(200),
  password:pwSchema.optional()
});
router.get('/users',secretaryOnly,async(req,res,next)=>{try{
  const {rows}=await pool.query(`SELECT u.id,u.username,u.email,u.role,u.status,u.member_id,m.full_name AS member_name,u.must_change_password,u.last_login_at,u.created_at
    FROM users u LEFT JOIN members m ON m.id=u.member_id AND m.organization_id=u.organization_id WHERE u.organization_id=$1 ORDER BY u.created_at`,[req.user.organization_id]);
  res.json({ok:true,users:rows.map(r=>({id:r.id,username:r.username,email:r.email,role:r.role,status:r.status,memberId:r.member_id,memberName:r.member_name,mustChangePassword:r.must_change_password,lastLoginAt:r.last_login_at,createdAt:r.created_at}))});
}catch(e){next(e);}});
router.post('/users',secretaryOnly,async(req,res,next)=>{
  const client=await pool.connect();
  try{
    const input=createUserSchema.parse(req.body);
    const username=cleanUsername(input.username);
    if(!isValidUsername(username))return res.status(400).json({ok:false,code:'USERNAME_INVALID',message:'Tên đăng nhập gồm 2–100 ký tự: chữ, số, dấu chấm, gạch dưới hoặc gạch ngang; không có khoảng trắng hay @.'});
    const org=req.user.organization_id;
    const generated=!input.password;const password=input.password||tempPassword();
    const hash=await bcrypt.hash(password,12);
    await client.query('BEGIN');
    // Hồ sơ đoàn viên được tạo/đồng bộ trong CHÍNH đơn vị của Bí thư (không nhận organizationId từ máy khách).
    await client.query(`INSERT INTO members(id,organization_id,full_name) VALUES($1,$2,$3) ON CONFLICT(id) DO NOTHING`,[input.memberId,org,input.fullName]);
    const mem=await client.query('SELECT id FROM members WHERE id=$1 AND organization_id=$2 AND archived_at IS NULL',[input.memberId,org]);
    if(!mem.rowCount){await client.query('ROLLBACK');return res.status(400).json({ok:false,code:'MEMBER_NOT_IN_UNIT',message:'Hồ sơ đoàn viên không thuộc đơn vị của bạn.'});}
    const ins=await client.query(`INSERT INTO users(organization_id,member_id,username,username_key,password_hash,role,status,must_change_password,created_by) VALUES($1,$2,$3,$4,$5,$6,'ACTIVE',true,$7) RETURNING id`,
      [org,input.memberId,username,normalizeUsername(username),hash,input.role,req.user.id]);
    await audit(client,req.user,'USER_CREATED','USER',ins.rows[0].id,{username,role:input.role,memberId:input.memberId});
    await client.query('COMMIT');
    res.status(201).json({ok:true,user:{id:ins.rows[0].id,username,role:input.role,memberId:input.memberId},...(generated?{temporaryPassword:password}:{}),message:'Đã tạo tài khoản. Người dùng phải đổi mật khẩu ở lần đăng nhập đầu.'});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});
    if(e.code==='23505')return res.status(409).json({ok:false,code:'DUPLICATE',message:'Tên đăng nhập đã tồn tại hoặc đoàn viên này đã có tài khoản.'});
    next(e);}finally{client.release();}
});
async function targetUser(req,res){
  const {rows}=await pool.query('SELECT id,role,username FROM users WHERE id=$1 AND organization_id=$2',[req.params.id,req.user.organization_id]);
  const u=rows[0];
  if(!u){res.status(404).json({ok:false,code:'NOT_FOUND',message:'Không tìm thấy tài khoản trong đơn vị.'});return null;}
  if(u.role==='Bí thư'||u.id===req.user.id){res.status(403).json({ok:false,code:'PROTECTED_ACCOUNT',message:'Không thể thao tác trên tài khoản Bí thư bằng chức năng này.'});return null;}
  return u;
}
router.post('/users/:id/reset-password',secretaryOnly,async(req,res,next)=>{try{
  if(!z.string().uuid().safeParse(req.params.id).success)return res.status(404).json({ok:false,message:'Không tìm thấy tài khoản.'});
  const body=z.object({password:pwSchema.optional()}).parse(req.body||{});
  const u=await targetUser(req,res);if(!u)return;
  const generated=!body.password;const password=body.password||tempPassword();
  const hash=await bcrypt.hash(password,12);
  await pool.query('UPDATE users SET password_hash=$1,must_change_password=true WHERE id=$2',[hash,u.id]);
  await pool.query('UPDATE auth_sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL',[u.id]);
  await audit(pool,req.user,'USER_PASSWORD_RESET','USER',u.id,{username:u.username});
  res.json({ok:true,...(generated?{temporaryPassword:password}:{}),message:'Đã đặt lại mật khẩu; mọi phiên đăng nhập cũ đã bị thu hồi.'});
}catch(e){next(e);}});
router.post('/users/:id/status',secretaryOnly,async(req,res,next)=>{try{
  if(!z.string().uuid().safeParse(req.params.id).success)return res.status(404).json({ok:false,message:'Không tìm thấy tài khoản.'});
  const {status}=z.object({status:z.enum(['ACTIVE','LOCKED'])}).parse(req.body);
  const u=await targetUser(req,res);if(!u)return;
  await pool.query('UPDATE users SET status=$1 WHERE id=$2',[status,u.id]);
  if(status==='LOCKED')await pool.query('UPDATE auth_sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL',[u.id]);
  await audit(pool,req.user,status==='LOCKED'?'USER_LOCKED':'USER_UNLOCKED','USER',u.id,{username:u.username});
  res.json({ok:true,message:status==='LOCKED'?'Đã khóa tài khoản.':'Đã mở khóa tài khoản.'});
}catch(e){next(e);}});

export default router;
