import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import nodemailer from 'nodemailer';
import { makeOpaqueToken, hashToken } from '../security.js';
import { z } from 'zod';
import { pool } from '../db.js';
import { config } from '../config.js';
import { requireAuth } from '../middleware/auth.js';
import { normalizeUsername } from '../username.js';

const router = Router();

const resetRequestSchema=z.object({email:z.string().email().max(254)});
const resetConfirmSchema=z.object({token:z.string().min(40).max(128),newPassword:z.string().min(12).max(200)});
function mailer(){
  if(!config.SMTP_HOST||!config.SMTP_USER||!config.SMTP_PASS||!config.SMTP_FROM) return null;
  return nodemailer.createTransport({host:config.SMTP_HOST,port:config.SMTP_PORT,secure:config.SMTP_SECURE==='true',auth:{user:config.SMTP_USER,pass:config.SMTP_PASS}});
}
router.post('/password-reset/request',async(req,res,next)=>{
  try{
    const {email}=resetRequestSchema.parse(req.body);
    const transport=mailer();
    if(!transport) return res.status(503).json({ok:false,code:'RESET_EMAIL_NOT_CONFIGURED',message:'Chức năng khôi phục mật khẩu chưa được cấu hình dịch vụ email. Vui lòng liên hệ quản trị viên.'});
    const {rows}=await pool.query('SELECT id,email FROM users WHERE lower(email)=lower($1) AND status=\'ACTIVE\' LIMIT 1',[email]);
    const user=rows[0];
    if(user){
      const token=makeOpaqueToken();
      await pool.query('UPDATE password_reset_tokens SET consumed_at=now() WHERE user_id=$1 AND consumed_at IS NULL',[user.id]);
      await pool.query(`INSERT INTO password_reset_tokens(user_id,token_hash,expires_at) VALUES($1,$2,now()+interval '30 minutes')`,[user.id,hashToken(token)]);
      const appBase=config.PUBLIC_APP_URL.replace(/#.*$/,'').replace(/\/index\.html?$/i,'').replace(/\/$/,'');
      const link=`${appBase}/?reset-token=${encodeURIComponent(token)}`;
      await transport.sendMail({from:config.SMTP_FROM,to:user.email,subject:'Khôi phục mật khẩu THANH NIÊN BA LĂNG',text:`Yêu cầu đặt lại mật khẩu đã được gửi. Liên kết có hiệu lực trong 30 phút: ${link}\nNếu không phải bạn yêu cầu, hãy bỏ qua email này.`});
    }
    // Do not disclose whether the email exists.
    res.json({ok:true,message:'Nếu email tồn tại và dịch vụ gửi thư hoạt động, hướng dẫn khôi phục sẽ được gửi.'});
  }catch(e){next(e);}
});
router.post('/password-reset/confirm',async(req,res,next)=>{
  const client=await pool.connect();
  try{
    const input=resetConfirmSchema.parse(req.body);
    const passwordHash=await bcrypt.hash(input.newPassword,12);
    await client.query('BEGIN');
    const {rows}=await client.query(`SELECT id,user_id FROM password_reset_tokens WHERE token_hash=$1 AND consumed_at IS NULL AND expires_at>now() FOR UPDATE`,[hashToken(input.token)]);
    if(!rows[0]){await client.query('ROLLBACK');return res.status(400).json({ok:false,message:'Liên kết khôi phục không hợp lệ hoặc đã hết hạn.'});}
    const userId=rows[0].user_id;
    await client.query('UPDATE users SET password_hash=$1 WHERE id=$2',[passwordHash,userId]);
    await client.query('UPDATE password_reset_tokens SET consumed_at=now() WHERE user_id=$1 AND consumed_at IS NULL',[userId]);
    await client.query('UPDATE auth_sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL',[userId]);
    await client.query('COMMIT');
    res.json({ok:true,message:'Đã đổi mật khẩu. Vui lòng đăng nhập lại.'});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});next(e);}finally{client.release();}
});

// Đăng nhập bằng tên đăng nhập (vd. TKBTCĐTBL). Trường "email" cũ vẫn được chấp nhận để tương thích,
// nhưng giá trị người dùng nhập không bao giờ bị tự đổi sang email.
const loginSchema = z.object({
  username:z.string().min(1).max(254).optional(),
  email:z.string().min(1).max(254).optional(),
  password:z.string().min(1).max(200)
}).refine(x=>x.username||x.email,{message:'Thiếu tên đăng nhập.'});
// Băm giả để thời gian phản hồi không tiết lộ tài khoản có tồn tại hay không.
const MAX_FAILS=10, LOCK_MINUTES=15;
const DUMMY_HASH=bcrypt.hashSync('khong-ton-tai-'+randomUUID(),12);
router.post('/login', async (req,res,next) => {
  try {
    const input = loginSchema.parse(req.body);
    const identifier = String(input.username ?? input.email).normalize('NFC').trim();
    const { rows } = await pool.query(
      'SELECT * FROM users WHERE username_key=$1::text OR (email IS NOT NULL AND lower(email)=lower($2::text)) ORDER BY COALESCE(username_key=$1::text,false) DESC LIMIT 1',
      [normalizeUsername(identifier),identifier]);
    const user = rows[0];
    const passwordOk = await bcrypt.compare(input.password, user?.password_hash || DUMMY_HASH);
    const throttled = !!user?.login_locked_until && new Date(user.login_locked_until) > new Date();
    if (!user || user.status !== 'ACTIVE' || !passwordOk || throttled) {
      if (user && user.status === 'ACTIVE' && !throttled) {
        // Sai liên tiếp MAX_FAILS lần -> khóa tạm LOCK_MINUTES phút (cùng một thông báo, không lộ tài khoản có tồn tại).
        await pool.query(`UPDATE users SET
          failed_login_count=CASE WHEN failed_login_count+1>=$2 THEN 0 ELSE failed_login_count+1 END,
          login_locked_until=CASE WHEN failed_login_count+1>=$2 THEN now()+($3||' minutes')::interval ELSE login_locked_until END
          WHERE id=$1`,[user.id,MAX_FAILS,String(LOCK_MINUTES)]);
      }
      return res.status(401).json({ok:false,code:'LOGIN_FAILED',message:'Tên đăng nhập hoặc mật khẩu không đúng, hoặc tài khoản đang tạm khóa do nhập sai nhiều lần.'});
    }
    await pool.query('UPDATE users SET failed_login_count=0,login_locked_until=NULL WHERE id=$1',[user.id]);
    const sessionId=randomUUID();
    const token = jwt.sign({org:user.organization_id, role:user.role, sid:sessionId},config.JWT_SECRET,{subject:user.id,algorithm:'HS256',expiresIn:config.JWT_EXPIRES_IN});
    const claims=jwt.decode(token);
    await pool.query(`INSERT INTO auth_sessions(id,user_id,organization_id,expires_at,user_agent) VALUES($1,$2,$3,to_timestamp($4),$5)`,[sessionId,user.id,user.organization_id,claims.exp, String(req.headers['user-agent']||'').slice(0,500)]);
    await pool.query('UPDATE users SET last_login_at=now() WHERE id=$1',[user.id]);
    await pool.query(`INSERT INTO audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,details) VALUES($1,$2,'LOGIN','USER',$3,'{}')`,[user.organization_id,user.id,String(user.id)]);
    res.json({ok:true,token,expiresIn:config.JWT_EXPIRES_IN,user:{id:user.id,username:user.username,email:user.email,role:user.role,memberId:user.member_id,organizationId:user.organization_id,mustChangePassword:!!user.must_change_password}});
  } catch(e){ next(e); }
});
router.get('/me',requireAuth,async(req,res,next)=>{try{const {rows}=await pool.query(`SELECT u.id,u.username,u.email,u.must_change_password,u.role,u.member_id,u.organization_id,m.full_name AS member_name,o.name AS organization_name FROM users u LEFT JOIN members m ON m.id=u.member_id AND m.organization_id=u.organization_id LEFT JOIN organizations o ON o.id=u.organization_id WHERE u.id=$1 LIMIT 1`,[req.user.id]);const u=rows[0];if(!u)return res.status(401).json({ok:false,code:'USER_NOT_FOUND',message:'Tài khoản không còn tồn tại.'});res.json({ok:true,user:{id:u.id,username:u.username,mustChangePassword:!!u.must_change_password,email:u.email,role:u.role,memberId:u.member_id,memberName:u.member_name||null,organizationId:u.organization_id,organizationName:u.organization_name||null}});}catch(e){next(e);}});
router.post('/logout',requireAuth,async(req,res,next)=>{try{await pool.query('UPDATE auth_sessions SET revoked_at=now() WHERE id=$1 AND user_id=$2 AND revoked_at IS NULL',[req.user.session_id,req.user.id]);res.json({ok:true,message:'Đã kết thúc phiên đăng nhập.'});}catch(e){next(e);}});
router.post('/change-password',requireAuth,async(req,res,next)=>{try{
  const b=z.object({currentPassword:z.string().min(1).max(200),newPassword:z.string().min(12,'Mật khẩu mới phải có ít nhất 12 ký tự.').max(200)}).parse(req.body);
  const {rows}=await pool.query('SELECT password_hash FROM users WHERE id=$1',[req.user.id]);
  if(!rows[0]||!(await bcrypt.compare(b.currentPassword,rows[0].password_hash)))return res.status(400).json({ok:false,code:'WRONG_PASSWORD',message:'Mật khẩu hiện tại không đúng.'});
  if(b.currentPassword===b.newPassword)return res.status(400).json({ok:false,code:'SAME_PASSWORD',message:'Mật khẩu mới phải khác mật khẩu hiện tại.'});
  await pool.query('UPDATE users SET password_hash=$1,must_change_password=false WHERE id=$2',[await bcrypt.hash(b.newPassword,12),req.user.id]);
  await pool.query('UPDATE auth_sessions SET revoked_at=now() WHERE user_id=$1 AND id<>$2 AND revoked_at IS NULL',[req.user.id,req.user.session_id]);
  res.json({ok:true,message:'Đã đổi mật khẩu.'});
}catch(e){next(e);}});
export default router;
