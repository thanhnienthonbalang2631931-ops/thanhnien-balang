import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';
import { requirePermission } from '../middleware/permissions.js';
import { makeOpaqueToken, hashToken } from '../security.js';
import { config } from '../config.js';

const router = Router();
const issueSchema = z.object({
  memberId:z.string().min(1).max(100).nullable().optional(),
  recipientName:z.string().trim().min(1).max(200),
  title:z.string().trim().min(1).max(300),
  issuedOn:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  issuerName:z.string().trim().min(1).max(200),
  publicNote:z.string().max(500).default('')
});
const publicDto = row => ({
  valid:row.status==='ISSUED', status:row.status,
  certificate:row.status==='ISSUED' ? {
    recipientName:row.recipient_name, title:row.certificate_title,
    issuedOn:row.issued_on, issuerName:row.issuer_name, publicNote:row.public_note
  } : null,
  message:row.status==='ISSUED'?'Giấy chứng nhận hợp lệ.':'Giấy chứng nhận đã bị thu hồi.'
});

// Public route: token resolves to exactly one certificate; no listing, search or member profile data.
router.get('/public/verify/:token', async (req,res,next) => {
  try {
    const token=String(req.params.token||'');
    if(token.length<40||token.length>128) return res.status(404).json({ok:false,valid:false,message:'Không tìm thấy giấy chứng nhận.'});
    const {rows}=await pool.query(
      `SELECT recipient_name,certificate_title,issued_on,issuer_name,public_note,status
       FROM certificates WHERE token_hash=$1 LIMIT 1`,[hashToken(token)]);
    if(!rows[0]) return res.status(404).json({ok:false,valid:false,message:'Mã xác minh không hợp lệ.'});
    return res.json({ok:true,...publicDto(rows[0])});
  } catch(e){next(e);}
});

router.use(requireAuth);
router.get('/mine',async(req,res,next)=>{
  try {
    if(!req.user.member_id) return res.json({ok:true,certificates:[]});
    const {rows}=await pool.query(
      `SELECT id,recipient_name,certificate_title,issued_on,issuer_name,status,revoked_at
       FROM certificates WHERE organization_id=$1 AND member_id=$2 ORDER BY issued_on DESC`,
      [req.user.organization_id,req.user.member_id]);
    res.json({ok:true,certificates:rows});
  }catch(e){next(e);}
});
router.get('/',requirePermission('certificates','read_all',{allowExplicitGrant:false}),async(req,res,next)=>{
  try {
    const {rows}=await pool.query(
      `SELECT id,member_id,recipient_name,certificate_title,issued_on,issuer_name,status,revoked_at
       FROM certificates WHERE organization_id=$1 ORDER BY issued_on DESC LIMIT 500`,[req.user.organization_id]);
    res.json({ok:true,certificates:rows});
  }catch(e){next(e);}
});
router.post('/',requirePermission('certificates','issue',{allowExplicitGrant:false}),async(req,res,next)=>{
  try {
    const input=issueSchema.parse(req.body);
    if(input.memberId){
      const m=await pool.query('SELECT id FROM members WHERE id=$1 AND organization_id=$2 AND archived_at IS NULL',[input.memberId,req.user.organization_id]);
      if(!m.rowCount)return res.status(400).json({ok:false,message:'Hồ sơ đoàn viên không tồn tại trong đơn vị.'});
    }
    const token=makeOpaqueToken();
    const {rows}=await pool.query(
      `INSERT INTO certificates(organization_id,member_id,recipient_name,certificate_title,issued_on,issuer_name,public_note,token_hash,issued_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)
       RETURNING id,recipient_name,certificate_title,issued_on,issuer_name,status`,
      [req.user.organization_id,input.memberId||null,input.recipientName,input.title,input.issuedOn,input.issuerName,input.publicNote,hashToken(token),req.user.id]);
    await pool.query(`INSERT INTO audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,details)
      VALUES($1,$2,'CERTIFICATE_ISSUED','CERTIFICATE',$3,$4)`,[req.user.organization_id,req.user.id,rows[0].id,JSON.stringify({memberId:input.memberId||null})]);
    const appBase=config.PUBLIC_APP_URL.replace(/#.*$/,'').replace(/\/index\.html?$/i,'').replace(/\/$/,'');
    const verifyUrl=`${appBase}/verify-certificate?token=${encodeURIComponent(token)}`;
    res.status(201).json({ok:true,certificate:rows[0],verificationToken:token,verifyUrl});
  }catch(e){next(e);}
});
router.post('/:id/revoke',requirePermission('certificates','revoke',{allowExplicitGrant:false}),async(req,res,next)=>{
  try {
    const reason=z.object({reason:z.string().trim().min(5).max(500)}).parse(req.body).reason;
    const {rows}=await pool.query(
      `UPDATE certificates SET status='REVOKED',revoked_at=now(),revoked_by=$1,revoke_reason=$2
       WHERE id=$3 AND organization_id=$4 AND status='ISSUED'
       RETURNING id,status,revoked_at`,[req.user.id,reason,req.params.id,req.user.organization_id]);
    if(!rows[0])return res.status(404).json({ok:false,message:'Không tìm thấy giấy còn hiệu lực trong đơn vị.'});
    await pool.query(`INSERT INTO audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,details)
      VALUES($1,$2,'CERTIFICATE_REVOKED','CERTIFICATE',$3,$4)`,[req.user.organization_id,req.user.id,rows[0].id,JSON.stringify({reason})]);
    res.json({ok:true,certificate:rows[0]});
  }catch(e){next(e);}
});
export default router;
