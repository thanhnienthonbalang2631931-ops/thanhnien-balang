import { Router } from 'express';
import QRCode from 'qrcode';
import { z } from 'zod';
import { pool } from '../db.js';
import { config } from '../config.js';
import { makeOpaqueToken, hashToken, lateMinutes } from '../security.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';

const router = Router();
const managers = allowRoles('Bí thư');
const rosterReaders = allowRoles('Bí thư','Phó Bí thư');
const sessionInput = z.object({
  activityId:z.string().min(1).max(100),
  opensAt:z.string().datetime({offset:true}).optional(),
  closesAt:z.string().datetime({offset:true}),
  rotationSeconds:z.number().int().min(30).max(300).optional()
});
const appCheckinUrl = token => `${config.PUBLIC_APP_URL.replace(/#.*$/,'')}#qr-checkin=${encodeURIComponent(token)}`;
const iso = d => new Date(d).toISOString();
const isInRequiredSet = (activity, memberId) => {
  if (activity.required_mode !== 'Chỉ một số đoàn viên phải đi') return true;
  const ids = Array.isArray(activity.required_member_ids) ? activity.required_member_ids : [];
  return ids.map(String).includes(String(memberId));
};
async function audit(client, user, action, entityType, entityId, details={}, result='SUCCESS') {
  await client.query(`INSERT INTO audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,result,details) VALUES($1,$2,$3,$4,$5,$6,$7)`,
    [user.organization_id,user.id,action,entityType,String(entityId),result,JSON.stringify(details)]);
}
async function issueToken(client, session, rotationSeconds) {
  const token = makeOpaqueToken();
  const now = Date.now();
  const expiresAt = new Date(Math.min(now + config.QR_TOKEN_TTL_SECONDS*1000, new Date(session.closes_at).getTime()));
  if (expiresAt.getTime() <= now) throw Object.assign(new Error('Phiên điểm danh đã hết thời hạn.'),{status:409,code:'SESSION_EXPIRED'});
  const updated = await client.query(
    `UPDATE qr_attendance_sessions SET token_hash=$1, token_expires_at=$2, token_version=token_version+1, rotation_seconds=$3 WHERE id=$4 RETURNING *`,
    [hashToken(token),expiresAt,rotationSeconds,session.id]
  );
  return {session:updated.rows[0],token,expiresAt:iso(expiresAt)};
}

// Public, minimal information only; never returns roster or member data.
router.get('/public/:token', async (req,res,next) => {
  try {
    const token = String(req.params.token||'');
    if (token.length < 32 || token.length > 128) return res.status(404).json({ok:false,message:'Mã QR không hợp lệ.'});
    const {rows} = await pool.query(
      `SELECT s.id,s.status,s.opens_at,s.closes_at,s.token_expires_at,s.token_hash,
              a.name AS activity_name,a.activity_date,a.start_time,a.place
       FROM qr_attendance_sessions s JOIN activities a ON a.id=s.activity_id AND a.organization_id=s.organization_id
       WHERE s.token_hash=$1 LIMIT 1`,[hashToken(token)]);
    const s=rows[0];
    if(!s || s.status!=='OPEN' || new Date(s.token_expires_at)<=new Date() || new Date(s.closes_at)<=new Date())
      return res.status(410).json({ok:false,code:'QR_EXPIRED',message:'Mã QR đã hết hạn hoặc bị thu hồi. Vui lòng quét mã mới.'});
    res.json({ok:true,session:{id:s.id,status:s.status,opensAt:iso(s.opens_at),closesAt:iso(s.closes_at),tokenExpiresAt:iso(s.token_expires_at)},activity:{name:s.activity_name,date:s.activity_date,startTime:s.start_time,place:s.place}});
  } catch(e){next(e);}
});

router.use(requireAuth);

// Create a QR attendance session. Only the Secretary can issue a session.
router.post('/sessions',managers,async(req,res,next)=>{
  const client=await pool.connect();
  try{
    const input=sessionInput.parse(req.body);
    const opensAt=input.opensAt?new Date(input.opensAt):new Date();
    const closesAt=new Date(input.closesAt);
    if(closesAt<=opensAt || closesAt<=new Date()) return res.status(400).json({ok:false,message:'Thời gian đóng phải sau thời gian mở và trong tương lai.'});
    await client.query('BEGIN');
    const {rows}=await client.query('SELECT * FROM activities WHERE id=$1 AND organization_id=$2 FOR UPDATE',[input.activityId,req.user.organization_id]);
    const activity=rows[0];
    if(!activity) {await client.query('ROLLBACK');return res.status(404).json({ok:false,message:'Không tìm thấy hoạt động trong đơn vị của bạn.'});}
    if(activity.status==='Đã kết thúc'||activity.ended_at||activity.attendance_locked_at){await client.query('ROLLBACK');return res.status(409).json({ok:false,message:'Hoạt động hoặc bảng điểm danh đã khóa.'});}
    const active=await client.query(`SELECT id FROM qr_attendance_sessions WHERE organization_id=$1 AND activity_id=$2 AND status IN ('OPEN','PAUSED') AND closes_at>now() FOR UPDATE`,[req.user.organization_id,input.activityId]);
    if(active.rowCount){await client.query('ROLLBACK');return res.status(409).json({ok:false,message:'Hoạt động đang có phiên QR chưa đóng. Hãy tiếp tục hoặc đóng phiên hiện tại.'});}
    const placeholder=makeOpaqueToken();
    const rotation=input.rotationSeconds||config.QR_ROTATE_SECONDS;
    const {rows:created}=await client.query(
      `INSERT INTO qr_attendance_sessions(organization_id,activity_id,created_by,status,opens_at,closes_at,token_hash,token_expires_at,rotation_seconds)
       VALUES($1,$2,$3,'OPEN',$4,$5,$6,$7,$8) RETURNING *`,
      [req.user.organization_id,input.activityId,req.user.id,opensAt,closesAt,hashToken(placeholder),new Date(0),rotation]);
    const issued=await issueToken(client,created[0],rotation);
    await audit(client,req.user,'QR_SESSION_CREATED','QR_SESSION',issued.session.id,{activityId:input.activityId,opensAt:iso(opensAt),closesAt:iso(closesAt)});
    await client.query('COMMIT');
    const url=appCheckinUrl(issued.token);
    const qrDataUrl=await QRCode.toDataURL(url,{errorCorrectionLevel:'H',margin:2,width:360});
    res.status(201).json({ok:true,session:sessionDto(issued.session),token:issued.token,checkinUrl:url,qrDataUrl,tokenExpiresAt:issued.expiresAt});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});next(e);}finally{client.release();}
});

function sessionDto(s){return {id:s.id,activityId:s.activity_id,status:s.status,opensAt:iso(s.opens_at),closesAt:iso(s.closes_at),tokenExpiresAt:iso(s.token_expires_at),rotationSeconds:s.rotation_seconds,tokenVersion:s.token_version,createdAt:iso(s.created_at)};}

router.get('/sessions',rosterReaders,async(req,res,next)=>{
  try{
    await pool.query(`UPDATE qr_attendance_sessions SET status='CLOSED',closed_at=COALESCE(closed_at,now()),token_hash=encode(gen_random_bytes(32),'hex') WHERE organization_id=$1 AND status IN ('OPEN','PAUSED') AND closes_at<=now()`,[req.user.organization_id]);
    const activityId=String(req.query.activityId||'');
    const {rows}=await pool.query(
      `SELECT s.*,a.name AS activity_name FROM qr_attendance_sessions s JOIN activities a ON a.id=s.activity_id AND a.organization_id=s.organization_id
       WHERE s.organization_id=$1 AND ($2='' OR s.activity_id=$2) ORDER BY s.created_at DESC LIMIT 100`,[req.user.organization_id,activityId]);
    res.json({ok:true,sessions:rows.map(s=>({...sessionDto(s),activityName:s.activity_name}))});
  }catch(e){next(e);}
});

router.post('/sessions/:id/rotate',managers,async(req,res,next)=>{
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const {rows}=await client.query(`SELECT * FROM qr_attendance_sessions WHERE id=$1 AND organization_id=$2 FOR UPDATE`,[req.params.id,req.user.organization_id]);
    const s=rows[0];
    if(!s||s.status!=='OPEN'||new Date(s.closes_at)<=new Date()){await client.query('ROLLBACK');return res.status(409).json({ok:false,message:'Phiên QR không còn mở.'});}
    const issued=await issueToken(client,s,s.rotation_seconds);
    await audit(client,req.user,'QR_TOKEN_ROTATED','QR_SESSION',s.id,{tokenVersion:issued.session.token_version});
    await client.query('COMMIT');
    const url=appCheckinUrl(issued.token); const qrDataUrl=await QRCode.toDataURL(url,{errorCorrectionLevel:'H',margin:2,width:360});
    res.json({ok:true,session:sessionDto(issued.session),token:issued.token,checkinUrl:url,qrDataUrl,tokenExpiresAt:issued.expiresAt});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});next(e);}finally{client.release();}
});

router.post('/sessions/:id/:action',managers,async(req,res,next)=>{
  const action=String(req.params.action);
  if(!['pause','resume','close','revoke'].includes(action)) return res.status(404).json({ok:false,message:'Thao tác không hợp lệ.'});
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const {rows}=await client.query(`SELECT * FROM qr_attendance_sessions WHERE id=$1 AND organization_id=$2 FOR UPDATE`,[req.params.id,req.user.organization_id]);
    const s=rows[0];
    if(!s){await client.query('ROLLBACK');return res.status(404).json({ok:false,message:'Không tìm thấy phiên QR.'});}
    const allowed={pause:s.status==='OPEN',resume:s.status==='PAUSED'&&new Date(s.closes_at)>new Date(),close:['OPEN','PAUSED'].includes(s.status),revoke:['OPEN','PAUSED'].includes(s.status)};
    if(!allowed[action]){await client.query('ROLLBACK');return res.status(409).json({ok:false,message:'Không thể thực hiện thao tác ở trạng thái hiện tại.'});}
    const nextStatus={pause:'PAUSED',resume:'OPEN',close:'CLOSED',revoke:'REVOKED'}[action];
    let updated;
    if(action==='resume'){
      const issued=await issueToken(client,s,s.rotation_seconds);
      const {rows:rr}=await client.query(`UPDATE qr_attendance_sessions SET status='OPEN' WHERE id=$1 RETURNING *`,[s.id]);
      updated=rr[0];
      await audit(client,req.user,'QR_SESSION_RESUME','QR_SESSION',s.id,{status:'OPEN',tokenVersion:updated.token_version});
      await client.query('COMMIT');
      const url=appCheckinUrl(issued.token); const qrDataUrl=await QRCode.toDataURL(url,{errorCorrectionLevel:'H',margin:2,width:360});
      return res.json({ok:true,session:sessionDto(updated),token:issued.token,checkinUrl:url,qrDataUrl,tokenExpiresAt:issued.expiresAt});
    }
    const {rows:rr}=await client.query(
      `UPDATE qr_attendance_sessions SET status=$1,closed_at=CASE WHEN $1 IN ('CLOSED','REVOKED') THEN now() ELSE closed_at END,closed_by=CASE WHEN $1 IN ('CLOSED','REVOKED') THEN $2 ELSE closed_by END,token_hash=encode(gen_random_bytes(32),'hex') WHERE id=$3 RETURNING *`,
      [nextStatus,req.user.id,s.id]);
    updated=rr[0];
    await audit(client,req.user,`QR_SESSION_${action.toUpperCase()}`,'QR_SESSION',s.id,{status:nextStatus});
    await client.query('COMMIT');
    res.json({ok:true,session:sessionDto(updated)});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});next(e);}finally{client.release();}
});

// Member identity comes only from the signed-in account. No memberId is accepted from client.
router.post('/check-in',async(req,res,next)=>{
  const client=await pool.connect();
  try{
    const token=String(req.body?.token||'');
    if(token.length<32||token.length>128)return res.status(400).json({ok:false,message:'Token QR không hợp lệ.'});
    if(!req.user.member_id)return res.status(403).json({ok:false,message:'Tài khoản chưa được liên kết với hồ sơ đoàn viên.'});
    await client.query('BEGIN');
    // Lock order is always Activity -> QR session -> Attendance row to avoid deadlocks
    // with the activity-lock endpoint and concurrent manual check-in operations.
    const lookup=await client.query(`SELECT id,activity_id FROM qr_attendance_sessions WHERE token_hash=$1 AND organization_id=$2 LIMIT 1`,[hashToken(token),req.user.organization_id]);
    const reject=async(status,code,message,sessionId='unknown')=>{await audit(client,req.user,'QR_CHECKIN_REJECTED','QR_SESSION',sessionId,{code,message},'REJECTED');await client.query('COMMIT');return res.status(status).json({ok:false,code,message});};
    if(!lookup.rows[0])return reject(410,'QR_INVALID','Mã QR không hợp lệ, đã bị thay mới hoặc bị thu hồi.');
    const activityResult=await client.query(`SELECT * FROM activities WHERE id=$1 AND organization_id=$2 FOR UPDATE`,[lookup.rows[0].activity_id,req.user.organization_id]);
    const activity=activityResult.rows[0];
    if(!activity)return reject(410,'QR_INVALID','Hoạt động của mã QR không còn tồn tại.',lookup.rows[0].id);
    const {rows}=await client.query(
      `SELECT s.*,a.name AS activity_name,a.activity_date,a.start_time,a.status AS activity_status,a.required_mode,a.required_member_ids,a.attendance_locked_at,a.ended_at
       FROM qr_attendance_sessions s JOIN activities a ON a.id=s.activity_id AND a.organization_id=s.organization_id
       WHERE s.id=$1 AND s.token_hash=$2 AND s.organization_id=$3 FOR UPDATE OF s`,[lookup.rows[0].id,hashToken(token),req.user.organization_id]);
    const s=rows[0];
    if(!s)return reject(410,'QR_INVALID','Mã QR đã được thay mới hoặc thu hồi.',lookup.rows[0].id);
    const now=new Date();
    if(s.status!=='OPEN'||new Date(s.token_expires_at)<=now||new Date(s.closes_at)<=now)return reject(410,'QR_EXPIRED','Mã QR đã hết hạn hoặc phiên đã đóng. Vui lòng quét mã mới.');
    if(new Date(s.opens_at)>now)return reject(409,'SESSION_NOT_OPEN','Phiên điểm danh chưa đến giờ mở.');
    if(s.activity_status==='Đã kết thúc'||s.ended_at||s.attendance_locked_at)return reject(409,'ATTENDANCE_LOCKED','Hoạt động hoặc bảng điểm danh đã khóa.');
    const {rows:memberRows}=await client.query(`SELECT id,member_status,archived_at FROM members WHERE id=$1 AND organization_id=$2`,[req.user.member_id,req.user.organization_id]);
    const member=memberRows[0];
    if(!member||member.archived_at||member.member_status!=='ACTIVE')return reject(403,'MEMBER_INACTIVE','Hồ sơ đoàn viên không hoạt động hoặc không thuộc đơn vị này.');
    if(!isInRequiredSet(s,req.user.member_id))return reject(403,'NOT_ELIGIBLE','Bạn không nằm trong danh sách đoàn viên được yêu cầu tham gia hoạt động này.');
    const mins=lateMinutes(s.activity_date,s.start_time,now);
    const status=mins>0?'Có mặt muộn':'Có mặt đúng giờ';
    const inserted=await client.query(
      `INSERT INTO attendance_records(organization_id,activity_id,session_id,member_id,status,checked_at,late_minutes,checkin_method,recorded_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,'QR',$8) ON CONFLICT(organization_id,activity_id,member_id) DO NOTHING RETURNING *`,
      [req.user.organization_id,s.activity_id,s.id,req.user.member_id,status,now,mins,req.user.id]);
    if(!inserted.rowCount){
      const {rows:existing}=await client.query(`SELECT status,checked_at,late_minutes,checkin_method FROM attendance_records WHERE organization_id=$1 AND activity_id=$2 AND member_id=$3`,[req.user.organization_id,s.activity_id,req.user.member_id]);
      await audit(client,req.user,'QR_CHECKIN_DUPLICATE','ATTENDANCE',`${s.activity_id}:${req.user.member_id}`,{sessionId:s.id},'REJECTED');
      await client.query('COMMIT');
      return res.status(409).json({ok:false,code:'ALREADY_CHECKED_IN',message:'Bạn đã được ghi nhận điểm danh cho hoạt động này.',attendance:existing[0]});
    }
    await audit(client,req.user,'QR_CHECKIN_SUCCESS','ATTENDANCE',inserted.rows[0].id,{activityId:s.activity_id,sessionId:s.id,status,lateMinutes:mins});
    await client.query('COMMIT');
    res.status(201).json({ok:true,message:'Điểm danh thành công.',attendance:{id:inserted.rows[0].id,activityId:s.activity_id,status,checkedAt:iso(now),lateMinutes:mins,method:'QR'}});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});next(e);}finally{client.release();}
});

router.get('/my-attendance',async(req,res,next)=>{
  try{
    if(!req.user.member_id)return res.status(403).json({ok:false,message:'Tài khoản chưa được liên kết với hồ sơ đoàn viên.'});
    const {rows}=await pool.query(
      `SELECT ar.activity_id,a.name AS activity_name,a.activity_date,ar.status,ar.checked_at,ar.late_minutes,ar.reason,ar.checkin_method
       FROM attendance_records ar JOIN activities a ON a.id=ar.activity_id AND a.organization_id=ar.organization_id
       WHERE ar.organization_id=$1 AND ar.member_id=$2 ORDER BY a.activity_date DESC,ar.checked_at DESC NULLS LAST`,
      [req.user.organization_id,req.user.member_id]);
    res.json({ok:true,records:rows.map(r=>({activityId:r.activity_id,activityName:r.activity_name,date:r.activity_date,status:r.status,checkedAt:r.checked_at?iso(r.checked_at):null,lateMinutes:r.late_minutes,reason:r.reason,method:r.checkin_method}))});
  }catch(e){next(e);}
});

router.get('/activities/:activityId/attendance',rosterReaders,async(req,res,next)=>{
  try{
    const {rows}=await pool.query(
      `SELECT ar.id,ar.member_id,m.full_name,ar.status,ar.checked_at,ar.late_minutes,ar.reason,ar.checkin_method
       FROM attendance_records ar JOIN members m ON m.id=ar.member_id AND m.organization_id=ar.organization_id
       JOIN activities a ON a.id=ar.activity_id AND a.organization_id=ar.organization_id
       WHERE ar.organization_id=$1 AND ar.activity_id=$2 ORDER BY m.full_name`,[req.user.organization_id,req.params.activityId]);
    res.json({ok:true,records:rows.map(r=>({id:r.id,memberId:r.member_id,memberName:r.full_name,status:r.status,checkedAt:r.checked_at?iso(r.checked_at):null,lateMinutes:r.late_minutes,reason:r.reason,method:r.checkin_method}))});
  }catch(e){next(e);}
});

router.post('/activities/:activityId/manual',managers,async(req,res,next)=>{
  const schema=z.object({memberId:z.string().min(1),status:z.enum(['Có mặt đúng giờ','Có mặt muộn','Vắng có phép','Vắng không lý do','Chưa xác nhận']),reason:z.string().max(1000).optional().default('')});
  const client=await pool.connect();
  try{
    const input=schema.parse(req.body); await client.query('BEGIN');
    const {rows:aRows}=await client.query(`SELECT * FROM activities WHERE id=$1 AND organization_id=$2 FOR UPDATE`,[req.params.activityId,req.user.organization_id]);
    const a=aRows[0]; if(!a){await client.query('ROLLBACK');return res.status(404).json({ok:false,message:'Không tìm thấy hoạt động.'});}
    if(a.attendance_locked_at||a.ended_at||a.status==='Đã kết thúc'){await client.query('ROLLBACK');return res.status(409).json({ok:false,message:'Bảng điểm danh đã khóa.'});}
    const {rows:mRows}=await client.query(`SELECT id FROM members WHERE id=$1 AND organization_id=$2 AND archived_at IS NULL`,[input.memberId,req.user.organization_id]);
    if(!mRows[0]){await client.query('ROLLBACK');return res.status(404).json({ok:false,message:'Không tìm thấy đoàn viên trong đơn vị.'});}
    const now=new Date(); const checkedAt=input.status.startsWith('Có mặt')?now:null;
    const mins=input.status==='Có mặt muộn'?lateMinutes(a.activity_date,a.start_time,now):0;
    const {rows}=await client.query(
      `INSERT INTO attendance_records(organization_id,activity_id,member_id,status,checked_at,late_minutes,reason,checkin_method,recorded_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,'MANUAL',$8)
       ON CONFLICT(organization_id,activity_id,member_id) DO UPDATE SET status=EXCLUDED.status,checked_at=EXCLUDED.checked_at,late_minutes=EXCLUDED.late_minutes,reason=EXCLUDED.reason,checkin_method='MANUAL',recorded_by=EXCLUDED.recorded_by,updated_at=now() RETURNING *`,
      [req.user.organization_id,a.id,input.memberId,input.status,checkedAt,mins,input.reason,req.user.id]);
    await audit(client,req.user,'ATTENDANCE_MANUAL_UPSERT','ATTENDANCE',rows[0].id,{activityId:a.id,memberId:input.memberId,status:input.status,reason:input.reason});
    await client.query('COMMIT'); res.json({ok:true,record:rows[0]});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});next(e);}finally{client.release();}
});

router.post('/activities/:activityId/lock',managers,async(req,res,next)=>{
  try{
    const client=await pool.connect();
    try{
      await client.query('BEGIN');
      const {rows}=await client.query(`UPDATE activities SET attendance_locked_at=COALESCE(attendance_locked_at,now()),updated_at=now() WHERE id=$1 AND organization_id=$2 RETURNING id`,[req.params.activityId,req.user.organization_id]);
      if(!rows[0]){await client.query('ROLLBACK');return res.status(404).json({ok:false,message:'Không tìm thấy hoạt động.'});}
      await client.query(`UPDATE qr_attendance_sessions SET status='CLOSED',closed_at=COALESCE(closed_at,now()),closed_by=$1,token_hash=encode(gen_random_bytes(32),'hex') WHERE organization_id=$2 AND activity_id=$3 AND status IN ('OPEN','PAUSED')`,[req.user.id,req.user.organization_id,req.params.activityId]);
      await audit(client,req.user,'ATTENDANCE_LOCKED','ACTIVITY',req.params.activityId,{});
      await client.query('COMMIT'); res.json({ok:true,message:'Đã khóa bảng điểm danh và đóng các phiên QR đang mở.'});
    }catch(e){await client.query('ROLLBACK').catch(()=>{});throw e;}finally{client.release();}
  }catch(e){next(e);}
});

export default router;
