// Chuẩn hóa tên đăng nhập: NFC, bỏ khoảng trắng hai đầu, chữ thường theo tiếng Việt.
// Không bao giờ chuyển tên đăng nhập thành email.
export const USERNAME_RE = /^[\p{L}\p{N}][\p{L}\p{N}._-]{1,99}$/u;
export function normalizeUsername(value) {
  return String(value ?? '').normalize('NFC').trim().toLocaleLowerCase('vi');
}
export function cleanUsername(value) {
  return String(value ?? '').normalize('NFC').trim();
}
export function isValidUsername(value) {
  return USERNAME_RE.test(cleanUsername(value));
}
