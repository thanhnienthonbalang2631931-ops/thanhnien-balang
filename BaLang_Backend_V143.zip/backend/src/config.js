import 'dotenv/config';
import { z } from 'zod';

const schema = z.object({
  NODE_ENV: z.string().default('development'),
  PORT: z.coerce.number().int().positive().default(4000),
  DATABASE_URL: z.string().min(1),
  JWT_SECRET: z.string().min(48, 'JWT_SECRET phải có ít nhất 48 ký tự'),
  JWT_EXPIRES_IN: z.string().default('8h'),
  CORS_ORIGINS: z.string().default(''),
  // Số lớp reverse proxy tin cậy phía trước Node (nginx = 1). 0 = không có proxy. Sai giá trị này làm giới hạn đăng nhập sai IP.
  TRUST_PROXY: z.coerce.number().int().min(0).max(5).default(0),
  PUBLIC_APP_URL: z.string().url(),
  QR_TOKEN_TTL_SECONDS: z.coerce.number().int().min(30).max(300).default(90),
  QR_ROTATE_SECONDS: z.coerce.number().int().min(30).max(300).default(60),
  SMTP_HOST: z.string().optional(), SMTP_PORT: z.coerce.number().int().positive().default(587),
  SMTP_SECURE: z.string().default('false'), SMTP_USER: z.string().optional(), SMTP_PASS: z.string().optional(),
  SMTP_FROM: z.string().email().optional()
});
export const config = schema.parse(process.env);
export const corsOrigins = config.CORS_ORIGINS.split(',').map(x => x.trim()).filter(Boolean);

if (config.NODE_ENV === 'production' && corsOrigins.length === 0) throw new Error('CORS_ORIGINS phải khai báo domain website khi chạy production.');
if (config.NODE_ENV === 'production' && config.TRUST_PROXY === 0) console.warn('[CẢNH BÁO] TRUST_PROXY=0 ở production: nếu có nginx/Caddy phía trước, mọi người dùng sẽ bị coi là cùng một IP. Đặt TRUST_PROXY=1.');
