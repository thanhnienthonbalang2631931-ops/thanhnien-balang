import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { pool } from '../db.js';

export async function requireAuth(req, res, next) {
  try {
    const raw = String(req.headers.authorization || '');
    const token = raw.startsWith('Bearer ') ? raw.slice(7) : '';
    if (!token) return res.status(401).json({ ok:false, code:'AUTH_REQUIRED', message:'Vui lòng đăng nhập.' });
    const claims = jwt.verify(token, config.JWT_SECRET, { algorithms:['HS256'] });
    if (!claims.sid) return res.status(401).json({ ok:false, code:'SESSION_INVALID', message:'Phiên đăng nhập không còn hợp lệ.' });
    const { rows } = await pool.query(
      `SELECT u.id,u.organization_id,u.member_id,u.email,u.role,u.status,u.must_change_password,s.id AS session_id
       FROM auth_sessions s JOIN users u ON u.id=s.user_id AND u.organization_id=s.organization_id
       WHERE s.id=$1 AND s.user_id=$2 AND s.organization_id=$3
         AND s.revoked_at IS NULL AND s.expires_at>now()`,
      [claims.sid,claims.sub,claims.org]
    );
    const user = rows[0];
    if (!user || user.status !== 'ACTIVE') return res.status(401).json({ ok:false, code:'SESSION_INVALID', message:'Phiên đăng nhập không còn hợp lệ.' });
    if (user.must_change_password && !['/api/auth/me','/api/auth/logout','/api/auth/change-password'].includes(req.baseUrl + req.path))
      return res.status(403).json({ ok:false, code:'PASSWORD_CHANGE_REQUIRED', message:'Bạn phải đổi mật khẩu tạm trước khi sử dụng hệ thống.' });
    req.user = user;
    // Best-effort activity timestamp; authorization does not depend on this update.
    pool.query('UPDATE auth_sessions SET last_seen_at=now() WHERE id=$1',[user.session_id]).catch(()=>{});
    return next();
  } catch (err) {
    if (err?.name === 'JsonWebTokenError' || err?.name === 'TokenExpiredError' || err?.name === 'NotBeforeError')
      return res.status(401).json({ ok:false, code:'SESSION_INVALID', message:'Phiên đăng nhập hết hạn hoặc không hợp lệ.' });
    return next(err);
  }
}

export function allowRoles(...roles) {
  return (req, res, next) => roles.includes(req.user?.role)
    ? next()
    : res.status(403).json({ ok:false, code:'FORBIDDEN', message:'Bạn không có quyền thực hiện thao tác này.' });
}
