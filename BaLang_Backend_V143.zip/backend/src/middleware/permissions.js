import { pool } from '../db.js';

// Permission decision is made against the authenticated database identity, never client-supplied role/org.
export function requirePermission(moduleKey, actionKey, { allowExplicitGrant = true } = {}) {
  return async (req, res, next) => {
    try {
      const user = req.user;
      if (!user) return res.status(401).json({ ok:false, code:'AUTH_REQUIRED', message:'Vui lòng đăng nhập.' });
      const { rows } = await pool.query(
        `SELECT EXISTS (
           SELECT 1 FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id
           WHERE rp.role=$1 AND p.module_key=$2 AND p.action_key=$3 AND rp.allowed=true
         ) AS role_allowed`, [user.role,moduleKey,actionKey]
      );
      if (rows[0]?.role_allowed) {
        req.permissionContext={moduleKey,actionKey,source:'ROLE',dataScope:'UNIT',scopePayload:{}};
        return next();
      }
      if (allowExplicitGrant) {
        const grants=await pool.query(
          `SELECT id,data_scope,scope_payload FROM user_permission_grants
           WHERE user_id=$1 AND organization_id=$2 AND module_key=$3 AND action_key=$4
             AND revoked_at IS NULL AND valid_from<=now() AND (valid_until IS NULL OR valid_until>now())
           ORDER BY created_at DESC`,[user.id,user.organization_id,moduleKey,actionKey]
        );
        if(grants.rowCount){
          req.permissionContext={moduleKey,actionKey,source:'GRANT',grants:grants.rows};
          return next();
        }
      }
      return res.status(403).json({ ok:false, code:'PERMISSION_DENIED', message:'Bạn không có quyền thực hiện thao tác này.' });
    } catch (error) { next(error); }
  };
}

// Route handlers must call this for every resource when a permission can be delegated.
// Resource shape: {organizationId, ownerUserId?, memberId?, recordId?}.
export async function hasDataScopeAccess(req, resource) {
  const ctx=req.permissionContext;
  if(!ctx || !resource?.organizationId) return false;
  const user=req.user;
  const scopes=ctx.source==='ROLE' ? [{data_scope:ctx.dataScope,scope_payload:{}}] : (ctx.grants||[]);
  for(const grant of scopes){
    const payload=grant.scope_payload||{};
    if(grant.data_scope==='SELF' && (resource.ownerUserId===user.id || (user.member_id && resource.memberId===user.member_id))) return true;
    if(grant.data_scope==='UNIT' && resource.organizationId===user.organization_id) return true;
    if(grant.data_scope==='DESCENDANTS'){
      const {rowCount}=await pool.query('SELECT 1 FROM organization_closure WHERE ancestor_id=$1 AND descendant_id=$2',[user.organization_id,resource.organizationId]);
      if(rowCount) return true;
    }
    if(grant.data_scope==='EXPLICIT'){
      const orgs=Array.isArray(payload.organizationIds)?payload.organizationIds:[];
      const members=Array.isArray(payload.memberIds)?payload.memberIds:[];
      const records=Array.isArray(payload.recordIds)?payload.recordIds:[];
      if(orgs.includes(resource.organizationId) || (resource.memberId && members.includes(resource.memberId)) || (resource.recordId && records.includes(resource.recordId))) return true;
    }
  }
  return false;
}
