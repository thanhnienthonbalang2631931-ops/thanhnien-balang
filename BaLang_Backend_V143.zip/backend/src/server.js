import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { rateLimit } from 'express-rate-limit';
import { ZodError } from 'zod';
import { config, corsOrigins } from './config.js';
import { pool } from './db.js';
import { normalizeUsername } from './username.js';
import authRoutes from './routes/auth.js';
import qrRoutes from './routes/qr.js';
import certificateRoutes from './routes/certificates.js';
import administrationRoutes from './routes/administration.js';
import memberRoutes from './routes/members.js';

const app=express();
app.disable('x-powered-by');
app.set('trust proxy',config.TRUST_PROXY);
app.use(helmet({crossOriginResourcePolicy:{policy:'cross-origin'}}));
app.use(cors({origin:(origin,cb)=>{if(!origin||corsOrigins.length===0||corsOrigins.includes(origin))return cb(null,true);cb(new Error('Origin không được phép.'));},methods:['GET','POST','PUT','PATCH','DELETE','OPTIONS'],allowedHeaders:['Content-Type','Authorization']}));
app.use('/api/members/import',express.json({limit:'2mb'})); // nhập hàng loạt cần giới hạn lớn hơn, chỉ cho đường dẫn này
app.use(express.json({limit:'32kb'}));
// Giới hạn đăng nhập: chỉ đếm lần SAI; khóa theo (IP + tên đăng nhập) để một người nhập sai không chặn cả xã dùng chung một IP,
// cộng thêm trần rộng theo IP để chặn dò hàng loạt nhiều tên.
const loginMsg={ok:false,code:'RATE_LIMIT',message:'Quá nhiều lần đăng nhập sai. Vui lòng thử lại sau ít phút.'};
app.use('/api/auth/login',rateLimit({windowMs:15*60*1000,limit:60,skipSuccessfulRequests:true,standardHeaders:'draft-8',legacyHeaders:false,message:loginMsg}));
app.use('/api/auth/login',rateLimit({windowMs:15*60*1000,limit:8,skipSuccessfulRequests:true,standardHeaders:'draft-8',legacyHeaders:false,message:loginMsg,
  keyGenerator:(req)=>`${req.ip}|${normalizeUsername(req.body?.username??req.body?.email??'').slice(0,100)}`,validate:{keyGeneratorIpFallback:false}}));
app.use('/api/auth/password-reset',rateLimit({windowMs:15*60*1000,limit:5,standardHeaders:'draft-8',legacyHeaders:false,message:{ok:false,code:'RATE_LIMIT',message:'Quá nhiều yêu cầu khôi phục. Vui lòng thử lại sau.'}}));
app.use('/api/certificates/public/verify',rateLimit({windowMs:60*1000,limit:60,standardHeaders:'draft-8',legacyHeaders:false,message:{ok:false,code:'RATE_LIMIT',message:'Quá nhiều lượt xác minh trong thời gian ngắn.'}}));
app.use('/api/qr/check-in',rateLimit({windowMs:60*1000,limit:120,standardHeaders:'draft-8',legacyHeaders:false,message:{ok:false,code:'RATE_LIMIT',message:'Quá nhiều yêu cầu điểm danh trong thời gian ngắn.'}}));
app.get('/health',async(_req,res)=>{try{await pool.query('SELECT 1');res.json({ok:true,service:'THANH NIEN BA LANG QR API',database:'connected',time:new Date().toISOString()});}catch{res.status(503).json({ok:false,database:'unavailable'});}});
app.use('/api/auth',authRoutes);
app.use('/api/qr',qrRoutes);
app.use('/api/certificates',certificateRoutes);
app.use('/api/admin',administrationRoutes);
app.use('/api/members',memberRoutes);
app.use((err,req,res,_next)=>{
  if(err instanceof ZodError)return res.status(400).json({ok:false,code:'VALIDATION_ERROR',message:'Dữ liệu gửi lên chưa hợp lệ.',issues:err.issues.map(x=>({path:x.path.join('.'),message:x.message}))});
  if(err.code==='23503')return res.status(400).json({ok:false,message:'Dữ liệu tham chiếu không tồn tại hoặc không thuộc đơn vị.'});
  if(err.code==='23505')return res.status(409).json({ok:false,message:'Dữ liệu đã tồn tại.'});
  const status=err.status||500;
  if(status>=500)console.error(err);
  res.status(status).json({ok:false,code:err.code||'INTERNAL_ERROR',message:status>=500?'Máy chủ gặp lỗi. Vui lòng thử lại hoặc liên hệ quản trị.':err.message});
});
const server=app.listen(config.PORT,()=>console.log(`QR API listening on :${config.PORT}`));
const shutdown=()=>server.close(async()=>{await pool.end();process.exit(0);});
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
