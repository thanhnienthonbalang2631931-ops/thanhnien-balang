import crypto from 'node:crypto';
export const makeOpaqueToken = () => crypto.randomBytes(32).toString('base64url');
export const hashToken = token => crypto.createHash('sha256').update(String(token)).digest('hex');
export const safeEqual = (a, b) => {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
};
export function lateMinutes(activityDate, startTime, now = new Date()) {
  const date = String(activityDate).slice(0, 10);
  const time = String(startTime).slice(0, 8);
  const start = new Date(`${date}T${time.length === 5 ? `${time}:00` : time}+07:00`);
  if (Number.isNaN(start.getTime())) throw new Error('Thời gian bắt đầu hoạt động không hợp lệ.');
  return Math.max(0, Math.floor((now.getTime() - start.getTime()) / 60000));
}
