param(
  [Parameter(Mandatory=$true)][string]$DatabaseUrl,
  [string]$TaskName = 'THANH NIEN BA LANG - PostgreSQL Backup',
  [string]$BackupRoot = "$PSScriptRoot\..\..\backups",
  [string]$Time = '02:00'
)
$ErrorActionPreference='Stop'
$backupScript=Join-Path $PSScriptRoot 'backup_postgres.ps1'
if(!(Get-Command pg_dump -ErrorAction SilentlyContinue)){throw 'Chưa tìm thấy pg_dump. Hãy cài PostgreSQL client tools và thêm vào PATH.'}
# Keep the connection string out of the scheduled-task command line. DPAPI protects it for this Windows account.
$secretFile=Join-Path $PSScriptRoot 'database-url.dpapi.xml'
$secure=ConvertTo-SecureString $DatabaseUrl -AsPlainText -Force
$secure | Export-Clixml -Path $secretFile
$acl=Get-Acl $secretFile
$acl.SetAccessRuleProtection($true,$false)
$rule=New-Object System.Security.AccessControl.FileSystemAccessRule($env:USERNAME,'FullControl','Allow')
$acl.SetAccessRule($rule);Set-Acl -Path $secretFile -AclObject $acl
$action=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$backupScript`" -BackupRoot `"$BackupRoot`" -UseProtectedConnection"
$trigger=New-ScheduledTaskTrigger -Daily -At $Time
$principal=New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Highest
$settings=New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 2)
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'Sao lưu PostgreSQL hằng ngày cho THANH NIÊN BA LĂNG.' -Force | Out-Null
Write-Output "Đã tạo tác vụ '$TaskName' chạy hằng ngày lúc $Time. Tác vụ chạy khi tài khoản Windows đang đăng nhập; máy chủ production cần lịch backup độc lập trên máy chủ 24/7."
