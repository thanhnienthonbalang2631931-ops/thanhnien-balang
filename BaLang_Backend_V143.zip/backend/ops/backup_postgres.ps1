param(
  [string]$DatabaseUrl,
  [switch]$UseProtectedConnection,
  [string]$BackupRoot = "$PSScriptRoot\..\..\backups",
  [int]$KeepDays = 30
)
$ErrorActionPreference = 'Stop'
if($UseProtectedConnection){
  $secretFile=Join-Path $PSScriptRoot 'database-url.dpapi.xml'
  if(!(Test-Path $secretFile)){throw 'Không tìm thấy chuỗi kết nối được bảo vệ. Hãy chạy install_backup_task.ps1.'}
  $secure=Import-Clixml -Path $secretFile
  $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try{$DatabaseUrl=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
}
if([string]::IsNullOrWhiteSpace($DatabaseUrl)){throw 'Thiếu DatabaseUrl.'}
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null
$target = Join-Path $BackupRoot "balang_$stamp.dump"
$log = Join-Path $BackupRoot "balang_$stamp.log"
try {
  $uri=[Uri]$DatabaseUrl
  $parts=$uri.UserInfo.Split(':',2)
  if($parts.Count -ne 2){throw 'DATABASE_URL phải có user và password.'}
  $db=[Uri]::UnescapeDataString($uri.AbsolutePath.TrimStart('/'))
  $dbPort=5432;if($uri.Port -gt 0){$dbPort=$uri.Port}
  $dbUser=[Uri]::UnescapeDataString($parts[0]);$dbPass=[Uri]::UnescapeDataString($parts[1])
  $escapePg={param($v) ([string]$v).Replace('\','\\').Replace(':','\:')}
  $pgpass=Join-Path $env:TEMP ("balang_pgpass_"+[guid]::NewGuid().ToString('N'))
  $line=(& $escapePg $uri.Host)+':'+$dbPort+':'+(& $escapePg $db)+':'+(& $escapePg $dbUser)+':'+(& $escapePg $dbPass)
  Set-Content -Path $pgpass -Value $line -NoNewline -Encoding Ascii
  $env:PGPASSFILE=$pgpass
  & pg_dump --host="$($uri.Host)" --port="$dbPort" --username="$dbUser" --dbname="$db" --format=custom --no-owner --no-acl --file="$target" 2>&1 | Tee-Object -FilePath $log
  if ($LASTEXITCODE -ne 0 -or !(Test-Path $target) -or (Get-Item $target).Length -lt 1024) { throw 'pg_dump thất bại hoặc tệp sao lưu bất thường.' }
  $check = & pg_restore --list "$target" 2>&1
  if ($LASTEXITCODE -ne 0 -or !$check) { throw 'Không đọc được danh mục trong bản sao lưu.' }
  Get-ChildItem $BackupRoot -Filter 'balang_*.dump' | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-$KeepDays) } | Remove-Item -Force
  Write-Output "BACKUP_OK $target"
} catch {
  Add-Content -Path $log -Value "BACKUP_FAILED: $_"
  throw
} finally {
  Remove-Item Env:PGPASSFILE -ErrorAction SilentlyContinue
  if($pgpass -and (Test-Path $pgpass)){Remove-Item $pgpass -Force}
}
